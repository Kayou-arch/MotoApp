package com.moto.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

// ---------- Réglages anti-pub ----------
/** Prépare la dernière radio en silence dès l'ouverture de Moto (la pub passe sans le son). */
const val PREWARM_ON_START = true
/** Après STOP, la radio reste connectée en silence ce temps-là : la relancer = pas de pub. */
const val WARM_MINUTES = 10L
// ---------------------------------------

data class Radio(val id: String, val name: String, val urls: List<String>)

/** Flux radio : plusieurs adresses par radio, essayées dans l'ordre. */
object Radios {
    val NRJ = Radio(
        "nrj", "NRJ", listOf(
            "https://cdn.nrjaudio.fm/audio1/fr/30001/mp3_128.mp3?origine=fluxradios",
            "http://cdn.nrjaudio.fm/audio1/fr/30001/mp3_128.mp3?origine=fluxradios"
        )
    )
    val FUN = Radio(
        "fun", "FUN RADIO", listOf(
            "https://icecast.funradio.fr/fun-1-44-128",
            "http://icecast.funradio.fr/fun-1-44-128",
            "http://streamer-02.rtl.fr/fun-1-44-128"
        )
    )
    fun byId(id: String?) = listOf(NRJ, FUN).find { it.id == id }
}

enum class RadioState { CONNECTING, PLAYING, RECONNECTING }

/**
 * Radio en arrière-plan.
 * Astuce anti-pub : la pub ne passe qu'à la connexion. On garde donc la connexion
 * ouverte en silence (après STOP, pendant la musique, ou dès l'ouverture de l'appli).
 */
class RadioService : Service(), AudioManager.OnAudioFocusChangeListener {

    companion object {
        /** Radio connectée (audible ou en silence). */
        var current: Radio? = null
            private set
        /** true = connectée mais en silence (« prête sans pub »). */
        var muted = false
            private set
        var state = RadioState.CONNECTING
            private set
        var lastError: Pair<Radio, String>? = null
            private set
        var onChange: (() -> Unit)? = null

        fun isOn(r: Radio) = current == r && !muted

        fun play(ctx: Context, r: Radio) {
            lastError = null
            if (current != r) { current = r; state = RadioState.CONNECTING }
            muted = false
            ctx.getSharedPreferences("radio", Context.MODE_PRIVATE).edit().putString("last", r.id).apply()
            send(ctx, "play", r)
        }

        /** Coupe le son mais garde la connexion (pas de pub à la reprise). */
        fun stop(ctx: Context) {
            if (current == null || muted) return
            muted = true
            send(ctx, "mute", null)
        }

        /** Prépare en silence la dernière radio écoutée. */
        fun warm(ctx: Context) {
            if (current != null) return
            val r = Radios.byId(ctx.getSharedPreferences("radio", Context.MODE_PRIVATE).getString("last", null)) ?: return
            current = r
            muted = true
            state = RadioState.CONNECTING
            send(ctx, "warm", r)
        }

        private fun send(ctx: Context, action: String, r: Radio?) {
            ctx.startForegroundService(Intent(ctx, RadioService::class.java).setAction(action).putExtra("id", r?.id))
        }
    }

    private var player: MediaPlayer? = null
    private var prepared = false
    private var connected: Radio? = null   // radio en cours de connexion / connectée
    private var focusReq: AudioFocusRequest? = null
    private var gen = 0
    private var retries = 0
    private var everPlayed = false
    private val handler = Handler(Looper.getMainLooper())
    private val am by lazy { getSystemService(AudioManager::class.java) }
    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    private val warmEnd = Runnable { shutdown() }
    private val prepareTimeout = Runnable { connected?.let { fail(it, "Réseau trop lent") } }

    override fun onBind(intent: Intent?) = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        val r = Radios.byId(intent?.getStringExtra("id"))
        when (intent?.action) {
            "mute" -> if (connected == null) shutdown() else mute()
            "warm" -> if (r == null) shutdown() else {
                muted = true
                ensureConnected(r)
                scheduleWarmEnd()
            }
            "play" -> if (r == null) shutdown() else {
                handler.removeCallbacks(warmEnd)
                current = r
                muted = false
                if (!requestFocus()) {
                    error(r, "Son occupé par une autre appli")
                } else if (connected == r) {
                    applyVolume()                          // déjà connectée : direct, sans pub
                    setState(if (prepared) RadioState.PLAYING else state)
                } else {
                    ensureConnected(r)
                }
            }
            else -> shutdown()                             // bouton STOP de la notification
        }
        return START_NOT_STICKY
    }

    // ---------- Connexion ----------

    private fun ensureConnected(r: Radio) {
        if (connected == r) return
        connected = r
        retries = 0
        everPlayed = false
        connect(r)
    }

    private fun connect(r: Radio) {
        releasePlayer()
        val g = ++gen
        setState(if (everPlayed) RadioState.RECONNECTING else RadioState.CONNECTING)
        Thread {
            var err = "Flux introuvable"
            var url: String? = null
            for (u in r.urls) {
                try { url = resolve(u); break } catch (e: Exception) { err = describe(e) }
            }
            handler.post {
                if (g != gen || connected != r) return@post
                val ok = url
                if (ok == null) fail(r, err) else prepare(r, ok, g)
            }
        }.start()
    }

    /** Suit les redirections (http → https) que le lecteur Android ne suit pas tout seul. */
    private fun resolve(start: String): String {
        var url = start
        repeat(6) {
            val c = (URL(url).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = 7000
                readTimeout = 7000
                setRequestProperty("User-Agent", "MotoApp/1.03")
                setRequestProperty("Icy-MetaData", "0")
            }
            try {
                when (val code = c.responseCode) {
                    in 200..299 -> return url
                    in 300..399 -> {
                        val loc = c.getHeaderField("Location") ?: throw IOException("redirection vide")
                        url = URL(URL(url), loc).toString()
                    }
                    else -> throw IOException("HTTP $code")
                }
            } finally {
                c.disconnect()
            }
        }
        throw IOException("trop de redirections")
    }

    private fun describe(e: Exception) = when (e) {
        is UnknownHostException -> "Pas de réseau"
        is SocketTimeoutException -> "Réseau trop lent"
        else -> "Flux introuvable" + (e.message?.let { " ($it)" } ?: "")
    }

    private fun prepare(r: Radio, url: String, g: Int) {
        try {
            player = MediaPlayer().apply {
                setAudioAttributes(attrs)
                setWakeMode(this@RadioService, PowerManager.PARTIAL_WAKE_LOCK)
                setDataSource(url)
                setOnPreparedListener {
                    if (g == gen) {
                        handler.removeCallbacks(prepareTimeout)
                        prepared = true
                        applyVolume()
                        it.start()
                        everPlayed = true
                        retries = 0
                        setState(RadioState.PLAYING)
                    }
                }
                setOnErrorListener { _, what, extra ->
                    if (g == gen) fail(r, "Lecture impossible ($what/$extra)")
                    true
                }
                setOnCompletionListener { if (g == gen) fail(r, "Flux coupé") }
                prepareAsync()
            }
            handler.postDelayed(prepareTimeout, 15000)
        } catch (e: Exception) {
            fail(r, describe(e))
        }
    }

    private fun fail(r: Radio, msg: String) {
        if (connected != r) return
        handler.removeCallbacks(prepareTimeout)
        releasePlayer()
        gen++
        val max = if (everPlayed) 10 else 2
        if (retries++ < max) {
            setState(if (everPlayed) RadioState.RECONNECTING else RadioState.CONNECTING)
            handler.postDelayed({ if (connected == r) connect(r) }, 3000)
        } else if (muted) {
            shutdown()                     // préparation silencieuse ratée : on n'embête pas
        } else {
            error(r, msg)
        }
    }

    private fun error(r: Radio, msg: String) {
        lastError = r to msg
        toast("${r.name} : $msg")
        shutdown()
    }

    // ---------- Son ----------

    private fun applyVolume() {
        val v = if (muted) 0f else 1f
        player?.setVolume(v, v)
    }

    private fun mute() {
        muted = true
        applyVolume()
        focusReq?.let { am.abandonAudioFocusRequest(it) }
        scheduleWarmEnd()
        setState(state)
    }

    private fun scheduleWarmEnd() {
        handler.removeCallbacks(warmEnd)
        handler.postDelayed(warmEnd, WARM_MINUTES * 60_000)
    }

    private fun requestFocus(): Boolean {
        val req = focusReq ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener(this)
            .build().also { focusReq = it }
        return am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    override fun onAudioFocusChange(change: Int) {
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> mute()                                   // ReFreezer démarre
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> player?.setVolume(0f, 0f)      // appel
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK ->                       // Waze parle
                if (!muted) player?.setVolume(0.3f, 0.3f)
            AudioManager.AUDIOFOCUS_GAIN -> applyVolume()
        }
    }

    // ---------- État / notification ----------

    private fun setState(s: RadioState) {
        state = s
        connected?.let { getSystemService(NotificationManager::class.java).notify(1, buildNotif(it.name)) }
        onChange?.invoke()
    }

    private fun statusText() = when {
        muted -> "Prête sans pub · arrêt auto dans $WARM_MINUTES min"
        state == RadioState.CONNECTING -> "Recherche…"
        state == RadioState.RECONNECTING -> "Reconnexion…"
        else -> "En direct"
    }

    private fun buildNotif(title: String): Notification {
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, RadioService::class.java).setAction("kill"), PendingIntent.FLAG_IMMUTABLE
        )
        val openPi = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, "radio")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title)
            .setContentText(statusText())
            .setContentIntent(openPi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_media_pause), "COUPER", stopPi
                ).build()
            )
            .build()
    }

    private fun startFg() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("radio", "Radio", NotificationManager.IMPORTANCE_LOW))
        val n = buildNotif(current?.name ?: "Radio")
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(1, n)
    }

    private fun releasePlayer() {
        player?.release()
        player = null
        prepared = false
    }

    private fun shutdown() {
        handler.removeCallbacksAndMessages(null)
        gen++
        releasePlayer()
        focusReq?.let { am.abandonAudioFocusRequest(it) }
        connected = null
        current = null
        muted = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        onChange?.invoke()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        releasePlayer()
        super.onDestroy()
    }
}
