# RidePlay (ex-Moto) — v1.13

## Accueil
- MUSIQUE : titre / artiste / temps (ou dernier écouté) + boutons ⏮ ▶ ⏭ directement sur l'accueil.
  Toucher le titre = écran musique complet.
- CONTACTS : haut = liste des favoris ; bas = 📞 dernier appel (reçu / appelé / manqué), toucher = rappeler.
- WAZE : affiche le guidage en cours (lu dans la notification de Waze).
- RADIOS : anti-pub. La pub ne passe qu'à la connexion, donc la radio reste connectée en silence :
  après STOP, pendant la musique, et dès l'ouverture de l'appli (dernière radio écoutée).
  Case « ✓ prête, sans pub » = relance instantanée sans pub. Coupure auto après 10 min de silence.
  Réglages en haut de RadioService.kt (PREWARM_ON_START, WARM_MINUTES). ≈ 1 Mo de données par minute.

## Réglages à faire une fois
1. Accès aux notifications → « Moto » (titre musique + guidage Waze).
   Si grisé : Paramètres > Applis > Moto > ⋮ > Autoriser les paramètres restreints.
2. Superposition → Moto (retour automatique après démarrage de ReFreezer).
3. Journal d'appels : toucher la case « 📞 Dernier appel ».

## v1.05
- Écran « Réglages » au démarrage tant qu'il manque une autorisation (lignes orange à toucher),
  y compris l'aide pas à pas pour « Autoriser les paramètres restreints ».
- Rouvrir les réglages : appui long sur le titre de la musique (accueil).

## v1.06
- 4 styles : Classique, Cockpit, Néon, Plein soleil — proposés au premier démarrage.
- Bouton ⚙ en haut de l'accueil : style + autorisations, modifiables à tout moment.

## v1.08
- Réglages redessinés : aperçus miniatures des 4 styles, autorisations en interrupteurs.
- Bouton « TOUT AUTORISER » qui enchaîne toutes les demandes.

## v1.09
- ▶ sur l'accueil : relance ReFreezer en arrière-plan sans l'ouvrir (ouverture seulement en dernier recours).
- « Titre & Waze » bloqué : ouvre d'abord Paramètres > Applis > Moto (paramètres restreints),
  puis l'accès aux notifications s'ouvre tout seul au retour.

## v1.10
- Case WAZE : appui = Waze + Moto en écran partagé (appui long = Waze plein écran).
- Mode compact automatique en écran partagé : titre + ⏮ ▶ ⏭, dernier appel, NRJ, FUN, ⚙.

## v1.11
- Corrige ReFreezer bloqué à 0:00 : plus aucune commande envoyée à ReFreezer fermé ;
  Moto l'ouvre, attend qu'il soit chargé, lance UNE fois, puis revient.
- Style Néon → Cyberpunk (jaune néon, cyan, rouge, coins coupés).

## v1.12
- Nouvelle icône : bouton lecture orange avec l'avant d'un roadster, fond noir.

## v1.13
- L'appli s'appelle maintenant RidePlay (nom sous l'icône, accueil, notification, réglages).

## v1.14
- Boutons ⏮ ▶/⏸ ⏭ et Favoris (aléatoire) redessinés : vraies icônes aux couleurs du style, plus d'émojis.

## v1.15
- 2 nouveaux styles : Rétro garage et Tactique (6 styles au total dans ⚙).

## Versions et GitHub
- Les zips sont nommés RidePlay-vX.YY.zip.
- Envoie simplement le nouveau zip : GitHub compile la version la plus haute,
  publie RidePlay-vX.YY.apk dans « Releases », garde les 3 dernières versions
  et supprime tout seul les anciens zips du dépôt.
- APK le plus récent : https://github.com/Kayou-arch/MotoApp/releases/latest

## v1.16
- Touches de l'accueil harmonisées : icônes dessinées partout (contacts, appel, Waze, radios, réglages),
  mêmes tailles de texte, rangées de même hauteur, textes d'état sans émojis.

## v1.17
- RETOUR avec icône dessinée (écran musique et contacts).
- Plein soleil : bouton lecture/pause cerclé de noir pour ne plus se fondre dans le fond jaune.

## v1.18
- Cyberpunk refait : couleurs « néon lumineux » (jaune, cyan, rouge), halos autour des cases,
  texte lumineux, et égaliseur animé sur la musique (seulement pendant la lecture).

## v1.19
- Icônes centrées avec leur texte dans chaque case (elles restaient collées en haut des boutons).

## v1.20
- Radios au choix : 12 radios + « autre radio » (adresse du flux), 2 ou 4 cases sur l'accueil (⚙ > Radios).
  Les 2 radios écoutées le plus récemment restent prêtes sans pub.
- Boutons de l'intercom : pendant la radio, ⏭ / ⏮ = radio suivante / précédente, ⏯ = pause / reprise.
  Commandes aussi sur l'écran verrouillé.
- Mode pluie (⚙ > Conduite) : appui d'au moins 0,3 s, les contacts brefs et à 2 doigts sont ignorés.

## v1.21
- Nouvelle icône « Horizon Montagnes » : grand soleil-lecture entre les sommets, route vers l'horizon.

## v1.22
- Radios auto-réparables : si une adresse de flux ne marche plus, RidePlay cherche la radio
  dans l'annuaire libre Radio Browser, prend la bonne adresse et la retient (corrige Rire & Chansons).

## v1.23
- Radios sur l'accueil : 1, 2, 3 ou 4 (⚙ > Radios), toutes préparées sans pub.
- Annuaire de secours : seulement la radio au nom exact (jamais une webradio thématique).
- Petit bouton « aléatoire » discret en haut à droite de la carte musique.

## v1.24
- Rire & Chansons, Chérie FM et Nostalgie : nouvelles adresses officielles du groupe NRJ (radios principales en direct).

## v1.25
- Le petit bouton de la carte musique (cœur) lance maintenant les FAVORIS en aléatoire
  (ouvre ReFreezer si besoin, puis revient sur l'accueil).

## v1.26
- Carte musique : bouton « Mon Flow » à gauche (Favoris en aléatoire reste à droite).

## v1.27
- Favoris : plus de début du 1er titre entendu. Son coupé le temps de mélanger, puis la musique
  démarre directement sur un titre au hasard (son rendu après 8 s maximum quoi qu'il arrive).

## v1.28
- Écran musique : bouton « MON FLOW » à côté de « FAVORIS » (icône cœur, comme sur l'accueil).

## v1.29
- Petits boutons Flow / Favoris plus grands, et ils montrent ce qui est en cours :
  pastille pleine = en cours de lecture, contour accent = en pause, contour fin = rien.

## v1.30
- Favoris : corrige le retour au 1er titre quand de la musique jouait déjà (on attend que les favoris
  démarrent vraiment avant de passer au hasard, et on surveille 4 s qu'ils ne reviennent pas au début).

## v1.31
- Corrige l'échec de compilation de la v1.30 (fonctions « en cours » des boutons Flow/Favoris).
  Le code est désormais compilé et vérifié avant chaque envoi.
