package com.moto.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch

/**
 * Réglages : choix du style (aperçus miniatures) + autorisations en interrupteurs.
 * « TOUT AUTORISER » enchaîne toutes les demandes une par une.
 */
class SetupActivity : Activity() {

    companion object {
        private fun granted(ctx: Context, p: String) =
            ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

        fun runtimePerms(): List<String> = buildList {
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            add(Manifest.permission.CALL_PHONE)
            add(Manifest.permission.READ_CALL_LOG)
        }

        fun notifOk(ctx: Context) =
            Build.VERSION.SDK_INT < 33 || granted(ctx, Manifest.permission.POST_NOTIFICATIONS)

        fun phoneOk(ctx: Context) =
            granted(ctx, Manifest.permission.CALL_PHONE) && granted(ctx, Manifest.permission.READ_CALL_LOG)

        fun listenerOk(ctx: Context) = ctx.hasListenerAccess()

        fun restrictedOk(ctx: Context): Boolean {
            if (Build.VERSION.SDK_INT < 33 || listenerOk(ctx)) return true
            return try {
                ctx.getSystemService(AppOpsManager::class.java).unsafeCheckOpNoThrow(
                    "android:access_restricted_settings", ctx.applicationInfo.uid, ctx.packageName
                ) == AppOpsManager.MODE_ALLOWED
            } catch (e: Exception) {
                false
            }
        }

        fun overlayOk(ctx: Context) = Settings.canDrawOverlays(ctx)

        fun batteryOk(ctx: Context) =
            ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)

        fun allOk(ctx: Context) =
            notifOk(ctx) && phoneOk(ctx) && listenerOk(ctx) && overlayOk(ctx) && batteryOk(ctx)

        fun isXiaomi() = Build.MANUFACTURER.lowercase() in setOf("xiaomi", "redmi", "poco")
    }

    private class Perm(
        val icon: String, val title: String, val desc: String,
        val ok: Boolean?, val toggle: Boolean = false, val action: () -> Unit
    )

    private lateinit var list: LinearLayout
    private val prefs by lazy { getSharedPreferences("setup", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())

    // Assistant « tout autoriser »
    private var wizard = false
    private var awaiting = false
    private val tried = mutableSetOf<String>()
    private var pendingListener = false   // retour de « Paramètres > Applis > Moto »

    private val green = Color.parseColor("#43A047")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val t = ui()
        val root = vbox()

        root.addFullWidth(label(30f, t.onBg, bold = true).apply {
            text = "Réglages"
            gravity = Gravity.START
            setPadding(dp(14), dp(10), dp(14), dp(2))
        })

        list = vbox()
        root.addWeighted(ScrollView(this).apply { addView(list) }, 1f)

        root.addView(bigButton("✓  C'EST PARTI", t.play, 24f) {
            markThemeChosen()
            finish()
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(84)).apply {
            setMargins(dp(5), dp(5), dp(5), dp(5))
        })

        setupScreen(root)
    }

    override fun onResume() {
        super.onResume()
        rebuild()
        // Retour de la page de l'appli : on enchaîne directement sur l'accès aux notifications
        if (pendingListener) {
            pendingListener = false
            if (!listenerOk(this)) {
                handler.postDelayed({ openListener() }, 300)
                return            // l'assistant reprendra au retour suivant
            }
        }
        if (wizard && awaiting) {
            awaiting = false
            handler.postDelayed({ nextStep() }, 350)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    // ---------- Construction de l'écran ----------

    private fun rebuild() {
        list.removeAllViews()
        val t = ui()

        section("Style", null)
        for (pair in Themes.all.chunked(2)) {
            val row = hbox()
            pair.forEach { row.addWeighted(themeCard(it), 1f) }
            list.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(230)))
        }

        // ---------- Conduite ----------
        section("Conduite", null)
        list.addView(permRow(Perm("🌧", "Mode pluie", "appui un peu plus long, les gouttes sont ignorées",
            rainMode(), toggle = true) { setRainMode(!rainMode()); rebuild() }), lp(dp(82)))

        // ---------- Radios ----------
        val n = RadioSlots.count(this)
        section("Radios", "$n sur l'accueil")
        list.addView(permRow(Perm("🔢", "Cases radio sur l'accueil", "toucher pour passer à ${if (n == 2) 4 else 2}",
            null) { RadioSlots.setCount(this, if (n == 2) 4 else 2); rebuild() }), lp(dp(82)))
        for (i in 0 until n) {
            val r = RadioSlots.slot(this, i)
            list.addView(permRow(Perm("📻", "Case ${i + 1} : ${r.name}", "toucher pour changer de radio", null) {
                pickRadio(i)
            }), lp(dp(82)))
        }

        val items = perms()
        val missing = items.count { it.ok == false }
        section("Autorisations", if (missing == 0) "✓ tout est activé" else "$missing à activer")

        if (missing > 0) {
            list.addView(
                bigButton(twoLine("⚡  TOUT AUTORISER", "je t'ouvre chaque réglage, tu valides", 0.55f), t.play, 24f) {
                    startWizard()
                },
                lp(dp(96))
            )
        }
        items.forEach { list.addView(permRow(it), lp(dp(82))) }

        list.addView(label(15f, withAlpha(t.onBg, 0x99)).apply {
            text = "Ne plus afficher au démarrage"
            paintFlags = paintFlags or Paint.UNDERLINE_TEXT_FLAG
            setPadding(dp(12), dp(22), dp(12), dp(22))
            isClickable = true
            setOnClickListener {
                prefs.edit().putBoolean("noAsk", true).apply()
                markThemeChosen()
                finish()
            }
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    }

    private fun lp(h: Int) = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, h).apply {
        setMargins(dp(5), dp(5), dp(5), dp(5))
    }

    private fun section(title: String, right: String?) {
        val t = ui()
        val row = hbox().apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(18), dp(12), dp(6))
        }
        row.addView(label(20f, t.onBg, bold = true).apply { text = title; gravity = Gravity.START },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        if (right != null) {
            row.addView(label(15f, if (right.startsWith("✓")) green else if (t.lightBg) t.onBg else t.accent, bold = true).apply { text = right })
        }
        list.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    }

    // ---------- Styles : aperçus miniatures ----------

    private fun themeCard(th: Theme): View {
        val t = ui()
        val selected = t.id == th.id
        val selColor = if (t.lightBg) t.onBg else t.accent
        val card = vbox().apply {
            setPadding(dp(8), dp(8), dp(8), dp(4))
            background = GradientDrawable().apply {
                setColor(t.panel.fill)
                cornerRadius = dp(20).toFloat()
                setStroke(dp(if (selected) 4 else 1), if (selected) selColor else Color.parseColor("#4D4D4D"))
            }
            isClickable = true
            contentDescription = "Style ${th.name}"
            setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                setUiTheme(th.id)
                recreate()
            }
        }
        card.addView(miniPreview(th), LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        card.addView(label(17f, t.panel.text, bold = true).apply {
            text = (if (selected) "✓ " else "") + th.name
            maxLines = 1
            setPadding(0, dp(6), 0, dp(2))
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        return card
    }

    /** Petit écran d'accueil dessiné dans les couleurs du style. */
    private fun miniPreview(th: Theme): View {
        val r = dp(5).toFloat()
        fun bg(s: Style): android.graphics.drawable.Drawable =
            if (th.chamfer) ChamferDrawable(s.fill, s.stroke,
                if (s.strokeDp > 0) maxOf(1, dp(s.strokeDp) / 2).toFloat() else 0f, dp(4).toFloat())
            else GradientDrawable().apply {
                setColor(s.fill)
                cornerRadius = r
                if (s.strokeDp > 0) setStroke(maxOf(1, dp(s.strokeDp) / 2), s.stroke)
            }
        fun box(s: Style) = View(this).apply { background = bg(s) }
        fun LinearLayout.mini(v: View, w: Float = 1f) {
            val m = dp(2)
            val p = if (orientation == LinearLayout.VERTICAL)
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, w)
            else LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, w)
            p.setMargins(m, m, m, m)
            addView(v, p)
        }
        fun textLine(color: Int, widthDp: Int, hDp: Int) = View(this).apply {
            background = GradientDrawable().apply { setColor(color); cornerRadius = dp(2).toFloat() }
        }.also { it.layoutParams = LinearLayout.LayoutParams(dp(widthDp), dp(hDp)).apply { topMargin = dp(2) } }

        val screen = vbox().apply {
            background = GradientDrawable().apply {
                setColor(th.bg)
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.parseColor("#3A3A3A"))
            }
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }

        // barre du haut avec ⚙
        val top = hbox()
        top.addView(View(this), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
        top.addView(box(th.neutral), LinearLayout.LayoutParams(dp(14), LinearLayout.LayoutParams.MATCH_PARENT).apply { setMargins(dp(2), dp(1), dp(2), dp(1)) })
        screen.mini(top, 0.28f)

        // musique
        val music = vbox().apply {
            background = bg(th.music)
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        music.addView(textLine(th.music.text, 44, 4))
        music.addView(textLine(withAlpha(th.music.text, 0x99), 28, 3))
        val ctr = hbox()
        ctr.mini(box(th.ctrl)); ctr.mini(box(th.play)); ctr.mini(box(th.ctrl))
        music.addView(ctr, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(3) })
        screen.mini(music, 1.35f)

        // contacts / waze
        val row1 = hbox()
        val cBox = vbox()
        cBox.mini(box(th.contacts), 1.5f)
        cBox.mini(box(th.contactsSub), 1f)
        row1.mini(cBox)
        row1.mini(box(th.waze))
        screen.mini(row1, 1.25f)

        // radios
        val row2 = hbox()
        row2.mini(box(th.nrj)); row2.mini(box(th.funR))
        screen.mini(row2, 1f)
        return screen
    }

    // ---------- Autorisations ----------

    private fun perms(): List<Perm> = buildList {
        add(Perm("🔔", "Notifications", "radio dans la barre", notifOk(this@SetupActivity)) { askRuntime() })
        add(Perm("📞", "Appels", "appeler + dernier appel", phoneOk(this@SetupActivity)) { askRuntime() })
        add(Perm("🎵", "Titre & Waze", "accès aux notifications", listenerOk(this@SetupActivity)) { openListenerSmart() })
        add(Perm("🪟", "Retour auto", "revenir sur RidePlay après ReFreezer", overlayOk(this@SetupActivity)) { openOverlay() })
        add(Perm("🔋", "Batterie", "la radio continue écran éteint", batteryOk(this@SetupActivity)) { openBattery() })
        if (isXiaomi()) add(Perm("🚀", "Démarrage auto", "Xiaomi · conseillé", null) { openAutostart() })
    }

    private fun permRow(p: Perm): View {
        val t = ui()
        val row = hbox().apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), 0, dp(14), 0)
            background = RippleDrawable(ColorStateList.valueOf(0x55888888), shape(t.panel, t), null)
            isClickable = true
            setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                if (p.ok == true && !p.toggle) {
                    toast("Pour le couper : réglages Android de l'appli")
                    openAppDetails()
                } else p.action()
            }
        }
        row.addView(label(26f, t.panel.text).apply { text = p.icon; maxLines = 1 },
            LinearLayout.LayoutParams(dp(42), LinearLayout.LayoutParams.WRAP_CONTENT))

        val col = vbox()
        col.addView(label(19f, t.panel.text, bold = true).apply { text = p.title; gravity = Gravity.START; maxLines = 1 },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        col.addView(label(14f, withAlpha(t.panel.text, 0xA8)).apply { text = p.desc; gravity = Gravity.START; maxLines = 1 },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8) })

        if (p.ok == null) {
            row.addView(label(30f, t.panel.text).apply { text = "›" }, LinearLayout.LayoutParams(dp(36), LinearLayout.LayoutParams.WRAP_CONTENT))
        } else {
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            row.addView(Switch(this).apply {
                isChecked = p.ok
                isClickable = false
                isFocusable = false
                thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, Color.parseColor("#BDBDBD")))
                trackTintList = ColorStateList(states, intArrayOf(green, Color.parseColor("#616161")))
                scaleX = 1.35f
                scaleY = 1.35f
            }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = dp(8)
            })
        }
        return row
    }

    // ---------- Assistant « tout autoriser » ----------

    private fun startWizard() {
        wizard = true
        tried.clear()
        nextStep()
    }

    private fun missingRuntime() = runtimePerms().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }

    private fun nextStep() {
        if (!wizard || isFinishing) return
        when {
            missingRuntime().isNotEmpty() && "runtime" !in tried -> {
                tried += "runtime"; awaiting = true; askRuntime()
            }
            !listenerOk(this) && "listener" !in tried -> {
                tried += "listener"; awaiting = true; openListenerSmart()
            }
            !overlayOk(this) && "overlay" !in tried -> {
                tried += "overlay"; awaiting = true; openOverlay()
            }
            !batteryOk(this) && "battery" !in tried -> {
                tried += "battery"; awaiting = true; openBattery()
            }
            else -> {
                wizard = false
                rebuild()
                toast(if (allOk(this)) "✓ Tout est activé" else "Il reste des lignes à activer : touche-les une par une")
            }
        }
    }

    // ---------- Actions ----------

    private fun askRuntime() {
        val missing = missingRuntime()
        if (missing.isEmpty()) { if (wizard) nextStep(); return }
        val askedBefore = prefs.getBoolean("askedRuntime", false)
        val blocked = askedBefore && missing.none { shouldShowRequestPermissionRationale(it) }
        if (blocked) {
            toast("Active-les dans « Autorisations »")
            openAppDetails()
        } else {
            prefs.edit().putBoolean("askedRuntime", true).apply()
            requestPermissions(missing.toTypedArray(), 10)
        }
    }

    /** Si bloqué : d'abord Paramètres > Applis > Moto, puis l'accès aux notifications tout seul. */
    private fun openListenerSmart() {
        if (restrictedOk(this)) openListener() else showRestrictedHelp()
    }

    private fun openListener() {
        val cn = ComponentName(this, MediaListener::class.java).flattenToString()
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                // ouvre directement l'interrupteur de Moto
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS)
                    .putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, cn))
            } else {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
    }

    private fun pickRadio(i: Int) {
        val names = Radios.catalog.map { it.name } + "➕  Autre radio (adresse du flux)…"
        AlertDialog.Builder(this)
            .setTitle("Case ${i + 1}")
            .setItems(names.toTypedArray()) { _, w ->
                if (w < Radios.catalog.size) { RadioSlots.setSlot(this, i, Radios.catalog[w]); rebuild() }
                else customRadio(i)
            }
            .show()
    }

    private fun customRadio(i: Int) {
        val name = android.widget.EditText(this).apply { hint = "Nom (ex. Ma radio)" }
        val url = android.widget.EditText(this).apply {
            hint = "https://…/flux.mp3"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        val box = vbox().apply { setPadding(dp(20), dp(8), dp(20), 0); addView(name); addView(url) }
        AlertDialog.Builder(this)
            .setTitle("Autre radio")
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                val n = name.text.toString().trim()
                val u = url.text.toString().trim()
                if (n.isNotEmpty() && (u.startsWith("http://") || u.startsWith("https://"))) {
                    RadioSlots.setSlot(this, i, Radios.custom(n, u)); rebuild()
                } else toast("Il faut un nom et une adresse qui commence par http")
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun showRestrictedHelp() {
        AlertDialog.Builder(this)
            .setTitle("🔓 Une étape à la main")
            .setMessage(
                "Android bloque « Titre & Waze » pour les applis installées hors Play Store.\n\n" +
                    "La page RidePlay va s'ouvrir :\n⋮ en haut à droite → « Autoriser les paramètres restreints ».\n\n" +
                    "Reviens ensuite : l'accès aux notifications s'ouvre tout seul, il n'y aura plus qu'à activer RidePlay."
            )
            .setPositiveButton("OUVRIR") { _, _ -> pendingListener = true; openAppDetails() }
            .setNegativeButton("Plus tard") { _, _ -> if (wizard) { awaiting = false; nextStep() } }
            .setOnCancelListener { if (wizard) { awaiting = false; nextStep() } }
            .show()
    }

    private fun openOverlay() =
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))

    private fun openBattery() {
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun openAutostart() {
        try {
            startActivity(Intent().setComponent(ComponentName(
                "com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"
            )))
        } catch (e: Exception) {
            openAppDetails()
        }
    }

    private fun openAppDetails() =
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        rebuild()
        if (wizard && awaiting) {
            awaiting = false
            handler.postDelayed({ nextStep() }, 350)
        }
    }
}
