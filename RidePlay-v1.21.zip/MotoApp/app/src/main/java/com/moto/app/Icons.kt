package com.moto.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ReplacementSpan
import android.view.View
import android.widget.TextView

/** Icônes dessinées (pas d'émoji) : prennent la couleur du texte du style. */
enum class Ic { PLAY, PAUSE, PREV, NEXT, SHUFFLE, PHONE, CALL, NAV, RADIO, GEAR, BACK }

class IconDrawable(var kind: Ic, color: Int, private val sizePx: Int) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color; style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }

    override fun getIntrinsicWidth() = sizePx
    override fun getIntrinsicHeight() = sizePx

    /** Mini-lecteur de tracés SVG (commandes absolues M L H V C Z). */
    private fun svg(d: String): Path {
        val p = Path()
        val tok = Regex("[MLHVCZ]|-?\\d*\\.?\\d+").findAll(d).map { it.value }.toList()
        var i = 0; var cmd = 'M'; var x = 0f; var y = 0f
        fun n() = tok[i++].toFloat()
        while (i < tok.size) {
            val t = tok[i]
            if (t[0].isLetter()) { cmd = t[0]; i++; if (cmd == 'Z') { p.close(); continue } }
            when (cmd) {
                'M' -> { x = n(); y = n(); p.moveTo(x, y); cmd = 'L' }
                'L' -> { x = n(); y = n(); p.lineTo(x, y) }
                'H' -> { x = n(); p.lineTo(x, y) }
                'V' -> { y = n(); p.lineTo(x, y) }
                'C' -> { val a = n(); val b = n(); val c = n(); val e = n(); x = n(); y = n(); p.cubicTo(a, b, c, e, x, y) }
                else -> i++
            }
        }
        return p
    }

    private fun tri(x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float) =
        Path().apply { moveTo(x1, y1); lineTo(x2, y2); lineTo(x3, y3); close() }

    override fun draw(c: Canvas) {
        val b = bounds
        val s = b.width() / 24f
        c.save()
        c.translate(b.left.toFloat(), b.top.toFloat())
        c.scale(s, s)
        line.strokeWidth = 2.2f
        when (kind) {
            Ic.PLAY -> {
                val p = tri(7f, 4.5f, 19.5f, 12f, 7f, 19.5f)
                c.drawPath(p, fill); line.strokeWidth = 1.6f; c.drawPath(p, line)
            }
            Ic.PAUSE -> {
                c.drawRoundRect(RectF(6f, 4.5f, 10f, 19.5f), 1.3f, 1.3f, fill)
                c.drawRoundRect(RectF(14f, 4.5f, 18f, 19.5f), 1.3f, 1.3f, fill)
            }
            Ic.PREV -> {
                val p = tri(18.5f, 5f, 8.5f, 12f, 18.5f, 19f)
                c.drawPath(p, fill); line.strokeWidth = 1.4f; c.drawPath(p, line)
                c.drawRoundRect(RectF(4.5f, 5f, 7.3f, 19f), 1f, 1f, fill)
            }
            Ic.NEXT -> {
                val p = tri(5.5f, 5f, 15.5f, 12f, 5.5f, 19f)
                c.drawPath(p, fill); line.strokeWidth = 1.4f; c.drawPath(p, line)
                c.drawRoundRect(RectF(16.7f, 5f, 19.5f, 19f), 1f, 1f, fill)
            }
            Ic.SHUFFLE -> {
                c.drawPath(Path().apply { moveTo(3f, 7f); lineTo(6.5f, 7f); cubicTo(11f, 7f, 12.5f, 17f, 17f, 17f); lineTo(20f, 17f) }, line)
                c.drawPath(Path().apply { moveTo(3f, 17f); lineTo(6.5f, 17f); cubicTo(11f, 17f, 12.5f, 7f, 17f, 7f); lineTo(20f, 7f) }, line)
                c.drawPath(Path().apply { moveTo(17.3f, 4.3f); lineTo(20f, 7f); lineTo(17.3f, 9.7f) }, line)
                c.drawPath(Path().apply { moveTo(17.3f, 14.3f); lineTo(20f, 17f); lineTo(17.3f, 19.7f) }, line)
            }
            Ic.PHONE -> {
                c.drawRoundRect(RectF(6.5f, 2.5f, 17.5f, 21.5f), 2.6f, 2.6f, line)
                c.drawLine(10.5f, 18f, 13.5f, 18f, line)
            }
            Ic.CALL -> c.drawPath(svg(
                "M6.6,10.8 C8,13.6 10.4,16 13.2,17.4 L15.4,15.2 C15.7,14.9 16.1,14.8 16.5,14.9 " +
                "C17.6,15.3 18.8,15.5 20,15.5 C20.6,15.5 21,15.9 21,16.5 V20 C21,20.6 20.6,21 20,21 " +
                "C10.6,21 3,13.4 3,4 C3,3.4 3.4,3 4,3 H7.5 C8.1,3 8.5,3.4 8.5,4 C8.5,5.3 8.7,6.5 9.1,7.6 " +
                "C9.2,8 9.1,8.4 8.8,8.7 Z"), fill)
            Ic.NAV -> {
                val p = svg("M3,11 L21,3 L13,21 L11,13 Z")
                c.drawPath(p, fill); line.strokeWidth = 1.4f; c.drawPath(p, line)
            }
            Ic.RADIO -> {
                c.drawRoundRect(RectF(3f, 8f, 21f, 21f), 2.5f, 2.5f, line)
                c.drawLine(6.5f, 8f, 17f, 3f, line)
                c.drawCircle(8.8f, 14.5f, 2.6f, fill)
                c.drawLine(13.5f, 12.8f, 18f, 12.8f, line)
                c.drawLine(13.5f, 16.4f, 18f, 16.4f, line)
            }
            Ic.BACK -> {
                line.strokeWidth = 2.8f
                c.drawPath(Path().apply { moveTo(14.5f, 5f); lineTo(7.5f, 12f); lineTo(14.5f, 19f) }, line)
            }
            Ic.GEAR -> {
                for (k in 0 until 8) {
                    c.save(); c.rotate(k * 45f, 12f, 12f)
                    c.drawRoundRect(RectF(10.4f, 1.6f, 13.6f, 5.6f), 0.8f, 0.8f, fill)
                    c.restore()
                }
                line.strokeWidth = 2.8f
                c.drawCircle(12f, 12f, 6.2f, line)
                line.strokeWidth = 2.2f
                c.drawCircle(12f, 12f, 2.4f, line)
            }
        }
        c.restore()
    }

    override fun setAlpha(alpha: Int) { fill.alpha = alpha; line.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { fill.colorFilter = cf; line.colorFilter = cf }
    @Deprecated("API Drawable")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}

/**
 * Place l'icône DANS le texte, centrée avec lui : l'ensemble icône + titre + sous-titre
 * est centré dans la case (les icônes « compound » d'Android restaient collées en haut).
 */
class CenteredImageSpan(private val d: Drawable) : ReplacementSpan() {
    override fun getSize(paint: Paint, text: CharSequence?, start: Int, end: Int, fm: Paint.FontMetricsInt?): Int {
        val r = d.bounds
        if (fm != null) {
            val p = paint.fontMetricsInt
            val fontH = p.descent - p.ascent
            if (r.height() > fontH) {
                val center = p.ascent + fontH / 2
                fm.ascent = center - r.height() / 2
                fm.descent = center + r.height() / 2
                fm.top = fm.ascent
                fm.bottom = fm.descent
            } else {
                fm.ascent = p.ascent; fm.descent = p.descent; fm.top = p.top; fm.bottom = p.bottom
            }
        }
        return r.width()
    }

    override fun draw(c: Canvas, text: CharSequence?, start: Int, end: Int, x: Float,
                      top: Int, y: Int, bottom: Int, paint: Paint) {
        c.save()
        c.translate(x, top + (bottom - top - d.bounds.height()) / 2f)
        d.draw(c)
        c.restore()
    }
}

/** Case qui affiche son icône au-dessus (ou à gauche) du texte, le tout centré. */
class IconTextView(ctx: Context) : TextView(ctx) {
    var icon: IconDrawable? = null
    var iconLeft = false
    private var raw: CharSequence = ""

    override fun setText(text: CharSequence?, type: BufferType?) {
        raw = text ?: ""
        val d = icon
        if (d == null) { super.setText(text, type); return }
        val sb = SpannableStringBuilder("\u200B")
        sb.setSpan(CenteredImageSpan(d), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (raw.isNotEmpty()) sb.append(if (iconLeft) "   " else "\n").append(raw)
        super.setText(sb, BufferType.SPANNABLE)
    }

    fun refresh() = setText(raw, BufferType.NORMAL)
}

private fun Context.makeIconView(kind: Ic, text: CharSequence, style: Style, iconDp: Int, textSp: Float,
                                 left: Boolean, onClick: (View) -> Unit): IconTextView {
    val v = IconTextView(this)
    val px = dp(iconDp)
    v.icon = IconDrawable(kind, style.text, px).apply { setBounds(0, 0, px, px) }
    v.iconLeft = left
    v.includeFontPadding = false
    return styleButton(v, text, style, textSp, onClick)
}

/** Gros bouton avec icône dessinée (+ libellé facultatif dessous), couleurs du style. */
fun Context.iconButton(kind: Ic, label: String?, style: Style, iconDp: Int, textSp: Float = 18f, onClick: (View) -> Unit): TextView =
    makeIconView(kind, label ?: "", style, iconDp, textSp, false, onClick).apply {
        contentDescription = label ?: kind.name
    }

/**
 * Case harmonisée : icône dessinée + titre (+ sous-titre), mêmes tailles partout.
 * left = icône à gauche du texte (pour les cases basses).
 */
fun Context.tile(kind: Ic, title: CharSequence, style: Style, iconDp: Int = 30, textSp: Float = 22f,
                 left: Boolean = false, onClick: (View) -> Unit): TextView =
    makeIconView(kind, title, style, iconDp, textSp, left, onClick)

/** Change l'icône d'un bouton existant (lecture ⇄ pause), et son libellé si besoin. */
fun TextView.setIcon(kind: Ic, label: String? = null) {
    val v = this as? IconTextView ?: return
    val d = v.icon ?: return
    val changed = d.kind != kind
    if (changed) d.kind = kind
    if (label != null && v.text.toString().substringAfter("\n") != label) { v.text = label; return }
    if (changed) v.refresh()
}
