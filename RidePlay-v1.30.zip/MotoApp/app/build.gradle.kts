plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.moto.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.moto.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 31
        versionName = "1.30"
    }
    // Clé fixe : chaque nouvelle version s'installe par-dessus l'ancienne
    signingConfigs {
        getByName("debug") {
            storeFile = file("moto.keystore")
            storePassword = "motoapp"
            keyAlias = "moto"
            keyPassword = "motoapp"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("debug") }
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
