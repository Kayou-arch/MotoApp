package com.moto.app

import android.content.ComponentName
import android.content.Context
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.view.KeyEvent

/** Outils communs pour piloter ReFreezer. */
object Music {
    private var pkgCache: String? = null
    private var lastSaved: String? = null

    fun pkg(ctx: Context): String? =
        pkgCache ?: ctx.findPackage(REFREEZER_PKG, "refreezer").also { pkgCache = it }

    fun controller(ctx: Context): MediaController? {
        val p = pkg(ctx) ?: return null
        if (!ctx.hasListenerAccess()) return null
        return try {
            ctx.getSystemService(MediaSessionManager::class.java)
                .getActiveSessions(ComponentName(ctx, MediaListener::class.java))
                .firstOrNull { it.packageName == p }
        } catch (e: SecurityException) {
            null
        }
    }

    fun isPlaying(c: MediaController?) = c?.playbackState?.state == PlaybackState.STATE_PLAYING

    /** Position et durée en ms. */
    fun position(c: MediaController, now: Long): Pair<Long, Long> {
        val st = c.playbackState
        val dur = c.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        var pos = st?.position ?: 0L
        if (st != null && st.state == PlaybackState.STATE_PLAYING) {
            pos += ((now - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
        }
        if (dur > 0) pos = pos.coerceIn(0L, dur)
        return pos to dur
    }

    fun fmt(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    /** Mémorise le dernier titre écouté. */
    fun remember(ctx: Context, c: MediaController) {
        val md = c.metadata ?: return
        val t = md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return
        val a = md.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val key = "$t|$a"
        if (key == lastSaved) return
        lastSaved = key
        ctx.getSharedPreferences("music", Context.MODE_PRIVATE).edit()
            .putString("title", t).putString("artist", a).apply()
    }

    fun last(ctx: Context): Pair<String, String>? {
        val p = ctx.getSharedPreferences("music", Context.MODE_PRIVATE)
        val t = p.getString("title", null) ?: return null
        return t to (p.getString("artist", "") ?: "")
    }

    /**
     * Envoie une touche média SEULEMENT si un lecteur joue déjà.
     * Envoyer « lecture » à ReFreezer fermé le démarre « à moitié » (bloqué à 0:00).
     */
    fun safeKey(ctx: Context, code: Int): Boolean {
        if (!ctx.getSystemService(AudioManager::class.java).isMusicActive) return false
        mediaKey(ctx, code)
        return true
    }

    /** Active l'aléatoire de ReFreezer (commande standard comprise par ReFreezer / audio_service). */
    fun shuffleOn(c: MediaController) {
        c.transportControls.sendCustomAction(
            "android.support.v4.media.session.action.SET_SHUFFLE_MODE",
            android.os.Bundle().apply { putInt("android.support.v4.media.session.action.ARGUMENT_SHUFFLE_MODE", 1) }
        )
    }

    /** Lance les favoris de ReFreezer en aléatoire (ReFreezer doit être lancé). done = message à afficher. */
    fun playFavorites(ctx: Context, done: (String) -> Unit) = play(ctx, MusicTarget.FAVORITES, done)

    /** Lance « Mon Flow » de ReFreezer (radio perso infinie : pas d'aléatoire). */
    fun playFlow(ctx: Context, done: (String) -> Unit) = play(ctx, MusicTarget.FLOW, done)

    /**
     * Lance les favoris en aléatoire SANS entendre le 1er titre, même si de la musique joue déjà :
     * 1. son coupé + pause (on ne confond plus l'ancien morceau avec le nouveau)
     * 2. lancement des favoris ; on attend qu'ils démarrent VRAIMENT (passage par un état « pas en lecture », puis lecture au début d'un titre)
     * 3. aléatoire + titre suivant ; son rendu dès que le titre tiré au hasard joue
     * 4. pendant 4 s on surveille : si ReFreezer revient au 1er titre, on recoupe et on repasse au suivant (2 fois max)
     * Sécurité : son rendu après 12 s quoi qu'il arrive.
     */
    private fun quietShuffleStart(app: Context, c: MediaController, mediaId: String) {
        val am = app.getSystemService(AudioManager::class.java)
        val h = android.os.Handler(android.os.Looper.getMainLooper())
        var muted = false
        fun mute() {
            if (muted) return
            try { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0); muted = true } catch (_: Exception) {}
        }
        fun unmute() {
            if (!muted) return
            muted = false
            try { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0) } catch (_: Exception) {}
        }
        fun now() = android.os.SystemClock.elapsedRealtime()
        fun pos(cc: MediaController): Long {
            val st = cc.playbackState ?: return Long.MAX_VALUE
            var p = st.position
            if (st.state == PlaybackState.STATE_PLAYING) p += ((now() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
            return p
        }

        mute()
        c.transportControls.pause()
        shuffleOn(c)
        val t0 = now()
        var sentAt = 0L
        h.postDelayed({
            controller(app)?.transportControls?.playFromMediaId(mediaId, null)
            sentAt = now()
        }, 300)

        var phase = 1               // 1 = attente du démarrage des favoris, 2 = attente du titre au hasard, 3 = surveillance
        var sawStopped = false
        var firstTitle: String? = null
        var watchUntil = 0L
        var retries = 0

        val tick = object : Runnable {
            override fun run() {
                val cc = controller(app)
                val title = cc?.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
                val playing = isPlaying(cc)
                if (sentAt > 0 && !playing) sawStopped = true
                when (phase) {
                    1 -> if (cc != null && sentAt > 0 && now() - sentAt > 500 && sawStopped && playing && pos(cc) < 5000) {
                        firstTitle = title
                        shuffleOn(cc)
                        cc.transportControls.skipToNext()
                        phase = 2
                    }
                    2 -> if (cc != null && playing && title != null && title != firstTitle) {
                        h.postDelayed({ unmute() }, 250)
                        watchUntil = now() + 4000
                        phase = 3
                    }
                    3 -> {
                        if (cc != null && title != null && title == firstTitle && retries < 2) {
                            // ReFreezer est revenu au 1er titre : on recoupe et on repasse au suivant
                            retries++
                            mute()
                            shuffleOn(cc)
                            cc.transportControls.skipToNext()
                            phase = 2
                        } else if (now() > watchUntil) return
                    }
                }
                if (now() - t0 > 12000) { unmute(); return }
                h.postDelayed(this, 200)
            }
        }
        h.postDelayed(tick, 400)
    }

    fun play(ctx: Context, target: MusicTarget, done: (String) -> Unit) {
        val app = ctx.applicationContext
        val p = pkg(app) ?: return done("ReFreezer introuvable sur le téléphone")
        FavoritesFinder(app, p, target) found@{ mediaId ->
            val c = controller(app) ?: run { done("ReFreezer ne répond pas"); return@found }
            if (target == MusicTarget.FLOW) {
                if (mediaId != null) { c.transportControls.playFromMediaId(mediaId, null); setMode(app, MusicTarget.FLOW); done("Mon Flow") }
                else done("Flow introuvable : lance-le une fois dans ReFreezer")
                return@found
            }
            if (mediaId != null) {
                quietShuffleStart(app, c, mediaId)
                setMode(app, MusicTarget.FAVORITES)
                done("Favoris en aléatoire")
            } else {
                shuffleOn(c)
                c.transportControls.play()
                done("Favoris non trouvés : aléatoire sur la liste en cours")
            }
        }.start()
    }

    fun mediaKey(ctx: Context, code: Int) {
        val am = ctx.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }
}
