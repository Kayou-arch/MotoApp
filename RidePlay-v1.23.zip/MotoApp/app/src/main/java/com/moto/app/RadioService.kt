package com.moto.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.MediaPlayer
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

// ---------- Réglages anti-pub ----------
/** Connecte les 2 radios en silence dès l'ouverture de Moto. */
const val PREWARM_ON_START = true
/** Une radio pas écoutée reste connectée en silence ce temps-là. */
const val WARM_MINUTES = 10L
/** Durée de la pub de démarrage : la radio reste muette ce temps-là après chaque connexion. */
const val PREROLL_SECONDS = 30L
// ---------------------------------------

enum class RadioState { CONNECTING, PLAYING, RECONNECTING }

/**
 * Les deux radios restent connectées en parallèle, en silence.
 * Changer de radio = couper le son de l'une, ouvrir celui de l'autre : pas de nouvelle connexion,
 * donc pas de nouvelle pub. Après chaque (re)connexion, la radio reste muette PREROLL_SECONDS.
 */
class RadioService : Service(), AudioManager.OnAudioFocusChangeListener {

    companion object {
        /** Radio qu'on entend (null = aucune). */
        var current: Radio? = null
            private set
        private val states = HashMap<String, RadioState>()
        private val readyAt = HashMap<String, Long>()
        var lastError: Pair<Radio, String>? = null
            private set
        var onChange: (() -> Unit)? = null

        fun isOn(r: Radio) = current == r
        fun stateOf(r: Radio): RadioState? = states[r.id]

        /** Secondes avant la fin de la pub muette (-1 = pas encore connectée). */
        fun secondsToLive(r: Radio): Long {
            val t = readyAt[r.id] ?: return -1
            val left = t - SystemClock.elapsedRealtime()
            return if (left <= 0) 0 else (left + 999) / 1000
        }

        fun play(ctx: Context, r: Radio) {
            lastError = null
            current = r
            RadioSlots.markUsed(ctx, r)
            states.putIfAbsent(r.id, RadioState.CONNECTING)
            send(ctx, "play", r)
        }

        fun stop(ctx: Context) {
            if (current == null) return
            current = null
            send(ctx, "mute", null)
        }

        /** Prépare en silence les 2 radios écoutées le plus récemment. */
        fun warm(ctx: Context) {
            val list = RadioSlots.warmList(ctx)
            if (list.all { states[it.id] != null }) return
            list.forEach { states.putIfAbsent(it.id, RadioState.CONNECTING) }
            ctx.startForegroundService(Intent(ctx, RadioService::class.java).setAction("warm")
                .putExtra("ids", list.map { it.id }.toTypedArray()))
        }

        private fun send(ctx: Context, action: String, r: Radio?) {
            ctx.startForegroundService(Intent(ctx, RadioService::class.java).setAction(action).putExtra("id", r?.id))
        }
    }

    private val channels = HashMap<String, Channel>()
    private var focusReq: AudioFocusRequest? = null
    private var focusVol = 1f
    private val handler = Handler(Looper.getMainLooper())
    private val am by lazy { getSystemService(AudioManager::class.java) }
    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    /** Ferme les radios inutilisées depuis WARM_MINUTES. */
    private val sweep = object : Runnable {
        override fun run() {
            val now = SystemClock.elapsedRealtime()
            for (ch in channels.values.toList()) {
                if (ch.r == current) ch.lastAudible = now
                else if (now - ch.lastAudible > WARM_MINUTES * 60_000) close(ch, null)
            }
            if (channels.isNotEmpty()) handler.postDelayed(this, 30_000)
        }
    }

    override fun onBind(intent: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        handler.postDelayed(sweep, 30_000)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        when (intent?.action) {
            "warm" -> intent?.getStringArrayExtra("ids")?.mapNotNull { Radios.byId(it) }?.forEach { ensure(it) }
            "play" -> {
                val r = Radios.byId(intent?.getStringExtra("id"))
                if (r == null) shutdown()
                else if (!requestFocus()) {
                    current = null
                    lastError = r to "Son occupé par une autre appli"
                    if (channels.isEmpty()) shutdown() else changed()
                } else {
                    focusVol = 1f
                    current = r
                    lastPlayed = r
                    ensure(r)                                  // les autres restent prêtes en silence
                    session().isActive = true
                    channels[r.id]?.lastAudible = SystemClock.elapsedRealtime()
                    applyAll()
                    changed()
                }
            }
            "mute" -> if (channels.isEmpty()) shutdown() else {
                current = null                             // pause : l'intercom peut relancer
                abandonFocus()
                applyAll()
                changed()
            }
            else -> shutdown()
        }
        return START_NOT_STICKY
    }

    private fun ensure(r: Radio) {
        if (channels[r.id] != null) return
        val ch = Channel(r)
        channels[r.id] = ch
        ch.connect()
    }

    // ---------- Un flux radio ----------

    private inner class Channel(val r: Radio) {
        var player: MediaPlayer? = null
        var gen = 0
        var retries = 0
        var everPlayed = false
        var lastAudible = SystemClock.elapsedRealtime()
        val timeout = Runnable { fail("Réseau trop lent") }

        fun alive() = channels[r.id] === this

        fun connect() {
            release()
            val g = ++gen
            setState(if (everPlayed) RadioState.RECONNECTING else RadioState.CONNECTING)
            Thread {
                var err = "Flux introuvable"
                var url: String? = null
                // 1) adresse qui a marché la dernière fois, puis adresses connues
                for (u in (listOfNotNull(cacheGet(r)) + r.urls).distinct()) {
                    try { url = resolve(u); break } catch (e: Exception) { err = describe(e) }
                }
                // 2) sinon : on cherche la radio dans l'annuaire Radio Browser et on retient la bonne adresse
                if (url == null && !r.id.startsWith("custom:")) {
                    for (u in lookup(r)) {
                        try { url = resolve(u); cachePut(r, u); break } catch (e: Exception) { err = describe(e) }
                    }
                }
                handler.post {
                    if (g != gen || !alive()) return@post
                    val ok = url
                    if (ok == null) fail(err) else prepare(ok, g)
                }
            }.start()
        }

        fun prepare(url: String, g: Int) {
            try {
                player = MediaPlayer().apply {
                    setAudioAttributes(attrs)
                    setWakeMode(this@RadioService, PowerManager.PARTIAL_WAKE_LOCK)
                    setDataSource(url)
                    setVolume(0f, 0f)
                    setOnPreparedListener {
                        if (g == gen && alive()) {
                            handler.removeCallbacks(timeout)
                            // la pub de démarrage passe en silence
                            readyAt[r.id] = SystemClock.elapsedRealtime() + PREROLL_SECONDS * 1000
                            handler.postDelayed({ if (alive()) { applyVolume(); changed() } }, PREROLL_SECONDS * 1000 + 50)
                            it.start()
                            everPlayed = true
                            retries = 0
                            setState(RadioState.PLAYING)
                        }
                    }
                    setOnErrorListener { _, what, extra ->
                        if (g == gen) fail("Lecture impossible ($what/$extra)")
                        true
                    }
                    setOnCompletionListener { if (g == gen) fail("Flux coupé") }
                    prepareAsync()
                }
                handler.postDelayed(timeout, 15000)
            } catch (e: Exception) {
                fail(describe(e))
            }
        }

        fun fail(msg: String) {
            if (!alive()) return
            handler.removeCallbacks(timeout)
            release()
            gen++
            val max = if (everPlayed) 10 else 2
            if (retries++ < max) {
                setState(if (everPlayed) RadioState.RECONNECTING else RadioState.CONNECTING)
                handler.postDelayed({ if (alive()) connect() }, 3000)
            } else {
                close(this, if (current == r) msg else null)
            }
        }

        fun applyVolume() {
            val ready = (readyAt[r.id] ?: Long.MAX_VALUE) <= SystemClock.elapsedRealtime()
            val v = if (r == current && ready) focusVol else 0f
            player?.setVolume(v, v)
        }

        fun setState(s: RadioState) {
            states[r.id] = s
            changed()
        }

        fun release() {
            player?.release()
            player = null
            readyAt.remove(r.id)
        }
    }

    private fun close(ch: Channel, err: String?) {
        handler.removeCallbacks(ch.timeout)
        ch.gen++
        ch.release()
        channels.remove(ch.r.id)
        states.remove(ch.r.id)
        if (err != null) {
            lastError = ch.r to err
            toast("${ch.r.name} : $err")
        }
        if (current == ch.r) { current = null; abandonFocus() }
        if (channels.isEmpty()) shutdown() else changed()
    }

    // ---------- Réseau ----------

    /** Suit les redirections (http → https) que le lecteur Android ne suit pas tout seul. */
    private fun resolve(start: String): String {
        var url = start
        repeat(6) {
            val c = (URL(url).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = 7000
                readTimeout = 7000
                setRequestProperty("User-Agent", "RidePlay/1.13")
                setRequestProperty("Icy-MetaData", "0")
            }
            try {
                when (val code = c.responseCode) {
                    in 200..299 -> return url
                    in 300..399 -> {
                        val loc = c.getHeaderField("Location") ?: throw IOException("redirection vide")
                        url = URL(URL(url), loc).toString()
                    }
                    else -> throw IOException("HTTP $code")
                }
            } finally {
                c.disconnect()
            }
        }
        throw IOException("trop de redirections")
    }

    // ---------- Annuaire Radio Browser (secours automatique) ----------

    /** Mémoire des adresses trouvées (vidée une fois en 1.23 : la 1.22 pouvait retenir une webradio thématique). */
    private fun cache() = getSharedPreferences("radio_cache", MODE_PRIVATE).also {
        if (it.getInt("v", 1) < 2) it.edit().clear().putInt("v", 2).apply()
    }
    private fun cacheGet(r: Radio) = cache().getString(r.id, null)
    private fun cachePut(r: Radio, url: String) = cache().edit().putString(r.id, url).apply()

    private fun norm(s: String) = java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD)
        .replace(Regex("[^a-z0-9]"), "")

    /** Cherche les adresses de flux de la radio (France), les plus proches du nom d'abord. */
    private fun lookup(r: Radio): List<String> {
        val want = (r.alias + r.name + r.search).map { norm(it) }.toSet()
        val q = java.net.URLEncoder.encode(r.search, "UTF-8")
        for (host in listOf("all.api.radio-browser.info", "de1.api.radio-browser.info", "fi1.api.radio-browser.info")) {
            try {
                val c = (URL("https://$host/json/stations/search?name=$q&countrycode=FR&hidebroken=true" +
                    "&order=votes&reverse=true&limit=30").openConnection() as HttpURLConnection).apply {
                    connectTimeout = 7000; readTimeout = 7000
                    setRequestProperty("User-Agent", "RidePlay/1.22")
                }
                val body = c.inputStream.bufferedReader().use { it.readText() }
                c.disconnect()
                val arr = org.json.JSONArray(body)
                return (0 until arr.length()).map { arr.getJSONObject(it) }
                    .filter { it.optString("url_resolved").startsWith("http") }
                    // nom exact uniquement : jamais une webradio thématique (« … Canulars », « … Sketches »)
                    .filter { norm(it.optString("name")) in want }
                    .sortedWith(compareBy<org.json.JSONObject>(
                        { norm(it.optString("name")) !in want },                       // nom exact d'abord
                        { o -> want.none { w -> norm(o.optString("name")).startsWith(w) } },
                        { it.optString("name").length }                                // puis le plus court
                    ))
                    .map { it.optString("url_resolved") }
                    .distinct()
                    .take(4)
            } catch (e: Exception) {
                // serveur suivant
            }
        }
        return emptyList()
    }

    private fun describe(e: Exception) = when (e) {
        is UnknownHostException -> "Pas de réseau"
        is SocketTimeoutException -> "Réseau trop lent"
        else -> "Flux introuvable" + (e.message?.let { " ($it)" } ?: "")
    }

    // ---------- Son ----------

    private fun applyAll() = channels.values.forEach { it.applyVolume() }

    private fun requestFocus(): Boolean {
        val req = focusReq ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener(this)
            .build().also { focusReq = it }
        return am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun abandonFocus() {
        focusReq?.let { am.abandonAudioFocusRequest(it) }
    }

    override fun onAudioFocusChange(change: Int) {
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> {                       // ReFreezer démarre
                current = null; focusVol = 1f; abandonFocus()
                mediaSession?.isActive = false                      // les boutons de l'intercom vont à ReFreezer
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> focusVol = 0f            // appel
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> focusVol = 0.3f // Waze parle
            AudioManager.AUDIOFOCUS_GAIN -> focusVol = 1f
        }
        applyAll()
        changed()
    }

    // ---------- Notification ----------

    private fun changed() {
        updateSession()
        if (channels.isNotEmpty()) getSystemService(NotificationManager::class.java).notify(1, buildNotif())
        onChange?.invoke()
    }

    // ---------- Boutons de l'intercom / du casque ----------

    private var mediaSession: MediaSession? = null
    private var lastPlayed: Radio? = null

    /**
     * Session média : quand une radio joue (ou vient d'être mise en pause), les boutons
     * de l'intercom pilotent la radio. ⏭ / ⏮ = radio suivante / précédente de l'accueil.
     */
    private fun session(): MediaSession = mediaSession ?: MediaSession(this, "RidePlayRadio").also { ms ->
        ms.setCallback(object : MediaSession.Callback() {
            override fun onPlay() { (lastPlayed ?: RadioSlots.slot(this@RadioService, 0)).let { play(this@RadioService, it) } }
            override fun onPause() = stop(this@RadioService)
            override fun onStop() = stop(this@RadioService)
            override fun onSkipToNext() = switchRadio(+1)
            override fun onSkipToPrevious() = switchRadio(-1)
        })
        mediaSession = ms
    }

    private fun switchRadio(dir: Int) {
        val slots = RadioSlots.home(this)
        val now = current ?: lastPlayed
        val i = slots.indexOfFirst { it.id == now?.id }
        val next = slots[((if (i < 0) 0 else i + dir) % slots.size + slots.size) % slots.size]
        play(this, next)
    }

    private fun updateSession() {
        val ms = mediaSession ?: return
        val shown = current ?: lastPlayed ?: return
        val playing = current != null
        ms.setPlaybackState(PlaybackState.Builder()
            .setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
                PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_STOP)
            .setState(if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1f)
            .build())
        ms.setMetadata(MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, shown.name)
            .putString(MediaMetadata.METADATA_KEY_ARTIST, "RidePlay · Radio")
            .build())
    }

    private fun buildNotif(): Notification {
        val cur = current
        val text = when {
            cur == null -> "Radios prêtes en silence (sans pub)"
            secondsToLive(cur) > 0 -> "${cur.name} · pub sautée…"
            states[cur.id] == RadioState.PLAYING -> "${cur.name} · en direct"
            else -> "${cur.name} · recherche…"
        }
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, RadioService::class.java).setAction("kill"), PendingIntent.FLAG_IMMUTABLE
        )
        val openPi = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, "radio")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("RidePlay · Radio")
            .setContentText(text)
            .setContentIntent(openPi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .apply { mediaSession?.let { setStyle(Notification.MediaStyle().setMediaSession(it.sessionToken)) } }
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_media_pause), "TOUT COUPER", stopPi
                ).build()
            )
            .build()
    }

    private fun startFg() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("radio", "Radio", NotificationManager.IMPORTANCE_LOW))
        val n = buildNotif()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(1, n)
    }

    private fun shutdown() {
        handler.removeCallbacksAndMessages(null)
        for (ch in channels.values.toList()) { ch.gen++; ch.release() }
        channels.clear()
        states.clear()
        readyAt.clear()
        current = null
        abandonFocus()
        mediaSession?.isActive = false
        mediaSession?.release()
        mediaSession = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        onChange?.invoke()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        for (ch in channels.values) ch.player?.release()
        mediaSession?.release()
        mediaSession = null
        super.onDestroy()
    }
}
