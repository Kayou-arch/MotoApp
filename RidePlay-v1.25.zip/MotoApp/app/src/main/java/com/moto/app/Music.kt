package com.moto.app

import android.content.ComponentName
import android.content.Context
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.view.KeyEvent

/** Outils communs pour piloter ReFreezer. */
object Music {
    private var pkgCache: String? = null
    private var lastSaved: String? = null

    fun pkg(ctx: Context): String? =
        pkgCache ?: ctx.findPackage(REFREEZER_PKG, "refreezer").also { pkgCache = it }

    fun controller(ctx: Context): MediaController? {
        val p = pkg(ctx) ?: return null
        if (!ctx.hasListenerAccess()) return null
        return try {
            ctx.getSystemService(MediaSessionManager::class.java)
                .getActiveSessions(ComponentName(ctx, MediaListener::class.java))
                .firstOrNull { it.packageName == p }
        } catch (e: SecurityException) {
            null
        }
    }

    fun isPlaying(c: MediaController?) = c?.playbackState?.state == PlaybackState.STATE_PLAYING

    /** Position et durée en ms. */
    fun position(c: MediaController, now: Long): Pair<Long, Long> {
        val st = c.playbackState
        val dur = c.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        var pos = st?.position ?: 0L
        if (st != null && st.state == PlaybackState.STATE_PLAYING) {
            pos += ((now - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
        }
        if (dur > 0) pos = pos.coerceIn(0L, dur)
        return pos to dur
    }

    fun fmt(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    /** Mémorise le dernier titre écouté. */
    fun remember(ctx: Context, c: MediaController) {
        val md = c.metadata ?: return
        val t = md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return
        val a = md.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val key = "$t|$a"
        if (key == lastSaved) return
        lastSaved = key
        ctx.getSharedPreferences("music", Context.MODE_PRIVATE).edit()
            .putString("title", t).putString("artist", a).apply()
    }

    fun last(ctx: Context): Pair<String, String>? {
        val p = ctx.getSharedPreferences("music", Context.MODE_PRIVATE)
        val t = p.getString("title", null) ?: return null
        return t to (p.getString("artist", "") ?: "")
    }

    /**
     * Envoie une touche média SEULEMENT si un lecteur joue déjà.
     * Envoyer « lecture » à ReFreezer fermé le démarre « à moitié » (bloqué à 0:00).
     */
    fun safeKey(ctx: Context, code: Int): Boolean {
        if (!ctx.getSystemService(AudioManager::class.java).isMusicActive) return false
        mediaKey(ctx, code)
        return true
    }

    /** Active l'aléatoire de ReFreezer (commande standard comprise par ReFreezer / audio_service). */
    fun shuffleOn(c: MediaController) {
        c.transportControls.sendCustomAction(
            "android.support.v4.media.session.action.SET_SHUFFLE_MODE",
            android.os.Bundle().apply { putInt("android.support.v4.media.session.action.ARGUMENT_SHUFFLE_MODE", 1) }
        )
    }

    /** Lance les favoris de ReFreezer en aléatoire (ReFreezer doit être lancé). done = message à afficher. */
    fun playFavorites(ctx: Context, done: (String) -> Unit) {
        val app = ctx.applicationContext
        val p = pkg(app) ?: return done("ReFreezer introuvable sur le téléphone")
        FavoritesFinder(app, p) found@{ mediaId ->
            val c = controller(app) ?: run { done("ReFreezer ne répond pas"); return@found }
            shuffleOn(c)
            if (mediaId != null) {
                c.transportControls.playFromMediaId(mediaId, null)
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                    controller(app)?.let { shuffleOn(it); it.transportControls.skipToNext() }
                }, 2500)
                done("Favoris en aléatoire")
            } else {
                c.transportControls.play()
                done("Favoris non trouvés : aléatoire sur la liste en cours")
            }
        }.start()
    }

    fun mediaKey(ctx: Context, code: Int) {
        val am = ctx.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }
}
