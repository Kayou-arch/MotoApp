package com.moto.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.TextUtils
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

// ---------- Réglages faciles à modifier ----------
const val REFREEZER_PKG = "r.r.refreezer"
const val WAZE_PKG = "com.waze"

val COLOR_MUSIC = Color.parseColor("#6A1B9A")
val COLOR_MUSIC_DARK = Color.parseColor("#4A148C")
val COLOR_CONTACTS = Color.parseColor("#2E7D32")
val COLOR_CONTACTS_DARK = Color.parseColor("#1B5E20")
val COLOR_WAZE = Color.parseColor("#0277BD")
val COLOR_NRJ = Color.parseColor("#C62828")
val COLOR_FUN = Color.parseColor("#EF6C00")
val COLOR_FAV = Color.parseColor("#F9A825")
val COLOR_GREY = Color.parseColor("#424242")
// -------------------------------------------------

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun Context.toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

/** Fond d'une case selon le thème (coins arrondis, ou coupés en biais). */
fun Context.shape(s: Style, t: Theme = ui()): Drawable =
    if (t.glow) GlowDrawable(
        s.fill, s.stroke, if (s.strokeDp > 0) dp(s.strokeDp).toFloat() else 0f,
        dp(t.radiusDp).toFloat(), dp(5).toFloat(), if (s.strokeDp > 0) s.stroke else s.fill
    )
    else if (t.chamfer) ChamferDrawable(s.fill, s.stroke, if (s.strokeDp > 0) dp(s.strokeDp).toFloat() else 0f, dp(14).toFloat())
    else GradientDrawable().apply {
        setColor(s.fill)
        cornerRadius = dp(t.radiusDp).toFloat()
        if (s.strokeDp > 0) setStroke(dp(s.strokeDp), s.stroke)
    }

/** Case aux coins coupés (haut-droit et bas-gauche), façon interface Cyberpunk. */
class ChamferDrawable(
    private val fill: Int, private val stroke: Int,
    private val strokeW: Float, private val cut: Float
) : Drawable() {
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fill; style = Paint.Style.FILL }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = stroke; style = Paint.Style.STROKE; strokeWidth = strokeW; strokeJoin = Paint.Join.MITER
    }
    private fun path(inset: Float): Path {
        val b = bounds
        val l = b.left + inset; val t = b.top + inset; val r = b.right - inset; val bt = b.bottom - inset
        return Path().apply {
            moveTo(l, t); lineTo(r - cut, t); lineTo(r, t + cut); lineTo(r, bt)
            lineTo(l + cut, bt); lineTo(l, bt - cut); close()
        }
    }
    override fun draw(canvas: Canvas) {
        canvas.drawPath(path(0f), fillPaint)
        if (strokeW > 0f) canvas.drawPath(path(strokeW / 2f), strokePaint)
    }
    override fun getOutline(outline: Outline) {
        if (Build.VERSION.SDK_INT >= 30) outline.setPath(path(0f)) else outline.setRect(bounds)
    }
    override fun setAlpha(alpha: Int) { fillPaint.alpha = alpha; strokePaint.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { fillPaint.colorFilter = cf; strokePaint.colorFilter = cf }
    @Deprecated("API Drawable")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}

/** Ancienne signature : couleur unie, texte blanc. */
fun Context.bigButton(text: CharSequence, color: Int, textSp: Float = 32f, onClick: (View) -> Unit): TextView =
    bigButton(text, Style(color, Color.WHITE), textSp, onClick)

/** Gros bouton selon le thème, vibration au toucher (utile avec des gants). */
fun Context.bigButton(text: CharSequence, style: Style, textSp: Float = 32f, onClick: (View) -> Unit): TextView =
    styleButton(TextView(this), text, style, textSp, onClick)

/** Applique le style du thème à n'importe quelle case (texte simple ou avec icône). */
fun <T : TextView> Context.styleButton(tv: T, text: CharSequence, style: Style, textSp: Float, onClick: (View) -> Unit): T =
    tv.apply {
        val t = ui()
        this.text = text
        setTextColor(style.text)
        textSize = textSp
        typeface = t.font
        // texte lumineux (sauf sur les cases pleines, où le texte est sombre)
        if (t.glow && style.strokeDp > 0) setShadowLayer(dp(6).toFloat(), 0f, 0f, withAlpha(style.text, 0xB0))
        gravity = Gravity.CENTER
        setPadding(dp(8), dp(8), dp(8), dp(8))
        background = RippleDrawable(ColorStateList.valueOf(0x55888888), shape(style, t), null)
        isClickable = true
        setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            onClick(it)
        }
    }

/** Texte simple centré. */
fun Context.label(sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
    textSize = sp
    setTextColor(color)
    gravity = Gravity.CENTER
    maxLines = 2
    ellipsize = TextUtils.TruncateAt.END
    if (bold) typeface = ui().font
    if (bold && ui().glow) setShadowLayer(dp(6).toFloat(), 0f, 0f, withAlpha(color, 0xB0))
}

/** Gros titre + petite ligne dessous. */
fun twoLine(main: String, sub: String, ratio: Float = 0.55f): CharSequence = SpannableStringBuilder(main).apply {
    if (sub.isNotEmpty()) {
        append("\n")
        val start = length
        append(sub)
        setSpan(RelativeSizeSpan(ratio), start, length, 0)
    }
}

fun Context.vbox() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
fun Context.hbox() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

fun LinearLayout.addWeighted(v: View, weight: Float) {
    val m = context.dp(5)
    val lp = if (orientation == LinearLayout.VERTICAL)
        LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, weight)
    else
        LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight)
    lp.setMargins(m, m, m, m)
    addView(v, lp)
}

fun LinearLayout.addFullWidth(v: View) =
    addView(v, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

/** Écran noir, toujours allumé, utilisable même verrouillé. */
fun Activity.setupScreen(root: View) {
    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    val t = ui()
    window.statusBarColor = t.bg
    window.navigationBarColor = t.bg
    @Suppress("DEPRECATION")
    window.decorView.systemUiVisibility = if (t.lightBg)
        View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else 0
    if (Build.VERSION.SDK_INT >= 27) setShowWhenLocked(true)
    root.setBackgroundColor(t.bg)
    root.setPadding(dp(4), dp(4), dp(4), dp(4))
    setContentView(root)
}

/** Trouve une appli par nom de paquet, sinon par son nom affiché. */
fun Context.findPackage(pkg: String, labelHint: String): String? {
    val pm = packageManager
    if (pm.getLaunchIntentForPackage(pkg) != null) return pkg
    return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        .firstOrNull { it.loadLabel(pm).toString().contains(labelHint, ignoreCase = true) }
        ?.activityInfo?.packageName
}

fun Activity.launchApp(pkg: String, labelHint: String) {
    val intent = findPackage(pkg, labelHint)?.let { packageManager.getLaunchIntentForPackage(it) }
    if (intent != null) startActivity(intent)
    else toast("$labelHint introuvable sur le téléphone")
}

fun Context.hasListenerAccess(): Boolean =
    Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        ?.contains(packageName) == true

fun Context.rounded(color: Int) = GradientDrawable().apply {
    setColor(color)
    cornerRadius = dp(28).toFloat()
}
