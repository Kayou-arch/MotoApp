package com.moto.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.view.View
import android.widget.TextView

/** Icônes dessinées (pas d'émoji) : prennent la couleur du texte du style. */
enum class Ic { PLAY, PAUSE, PREV, NEXT, SHUFFLE }

class IconDrawable(var kind: Ic, color: Int, private val sizePx: Int) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color; style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }

    override fun getIntrinsicWidth() = sizePx
    override fun getIntrinsicHeight() = sizePx

    private fun tri(x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float) =
        Path().apply { moveTo(x1, y1); lineTo(x2, y2); lineTo(x3, y3); close() }

    override fun draw(c: Canvas) {
        val b = bounds
        val s = b.width() / 24f
        c.save()
        c.translate(b.left.toFloat(), b.top.toFloat())
        c.scale(s, s)
        line.strokeWidth = 2.2f
        when (kind) {
            Ic.PLAY -> {
                val p = tri(7f, 4.5f, 19.5f, 12f, 7f, 19.5f)
                c.drawPath(p, fill); line.strokeWidth = 1.6f; c.drawPath(p, line)
            }
            Ic.PAUSE -> {
                c.drawRoundRect(RectF(6f, 4.5f, 10f, 19.5f), 1.3f, 1.3f, fill)
                c.drawRoundRect(RectF(14f, 4.5f, 18f, 19.5f), 1.3f, 1.3f, fill)
            }
            Ic.PREV -> {
                val p = tri(18.5f, 5f, 8.5f, 12f, 18.5f, 19f)
                c.drawPath(p, fill); line.strokeWidth = 1.4f; c.drawPath(p, line)
                c.drawRoundRect(RectF(4.5f, 5f, 7.3f, 19f), 1f, 1f, fill)
            }
            Ic.NEXT -> {
                val p = tri(5.5f, 5f, 15.5f, 12f, 5.5f, 19f)
                c.drawPath(p, fill); line.strokeWidth = 1.4f; c.drawPath(p, line)
                c.drawRoundRect(RectF(16.7f, 5f, 19.5f, 19f), 1f, 1f, fill)
            }
            Ic.SHUFFLE -> {
                c.drawPath(Path().apply { moveTo(3f, 7f); lineTo(6.5f, 7f); cubicTo(11f, 7f, 12.5f, 17f, 17f, 17f); lineTo(20f, 17f) }, line)
                c.drawPath(Path().apply { moveTo(3f, 17f); lineTo(6.5f, 17f); cubicTo(11f, 17f, 12.5f, 7f, 17f, 7f); lineTo(20f, 7f) }, line)
                c.drawPath(Path().apply { moveTo(17.3f, 4.3f); lineTo(20f, 7f); lineTo(17.3f, 9.7f) }, line)
                c.drawPath(Path().apply { moveTo(17.3f, 14.3f); lineTo(20f, 17f); lineTo(17.3f, 19.7f) }, line)
            }
        }
        c.restore()
    }

    override fun setAlpha(alpha: Int) { fill.alpha = alpha; line.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { fill.colorFilter = cf; line.colorFilter = cf }
    @Deprecated("API Drawable")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}

/** Gros bouton avec icône dessinée (+ libellé facultatif dessous), couleurs du style. */
fun Context.iconButton(kind: Ic, label: String?, style: Style, iconDp: Int, textSp: Float = 18f, onClick: (View) -> Unit): TextView =
    bigButton(label ?: "", style, if (label == null) 1f else textSp, onClick).apply {
        includeFontPadding = false
        val px = dp(iconDp)
        val d = IconDrawable(kind, style.text, px)
        d.setBounds(0, 0, px, px)
        setCompoundDrawables(null, d, null, null)
        compoundDrawablePadding = if (label == null) 0 else dp(6)
        contentDescription = label ?: kind.name
    }

/** Change l'icône d'un bouton existant (lecture ⇄ pause), et son libellé si besoin. */
fun TextView.setIcon(kind: Ic, label: String? = null) {
    val d = compoundDrawables[1] as? IconDrawable ?: return
    if (d.kind != kind) { d.kind = kind; d.invalidateSelf() }
    if (label != null && text.toString() != label) text = label
}
