# RidePlay (ex-Moto) — v1.13

## Accueil
- MUSIQUE : titre / artiste / temps (ou dernier écouté) + boutons ⏮ ▶ ⏭ directement sur l'accueil.
  Toucher le titre = écran musique complet.
- CONTACTS : haut = liste des favoris ; bas = 📞 dernier appel (reçu / appelé / manqué), toucher = rappeler.
- WAZE : affiche le guidage en cours (lu dans la notification de Waze).
- RADIOS : anti-pub. La pub ne passe qu'à la connexion, donc la radio reste connectée en silence :
  après STOP, pendant la musique, et dès l'ouverture de l'appli (dernière radio écoutée).
  Case « ✓ prête, sans pub » = relance instantanée sans pub. Coupure auto après 10 min de silence.
  Réglages en haut de RadioService.kt (PREWARM_ON_START, WARM_MINUTES). ≈ 1 Mo de données par minute.

## Réglages à faire une fois
1. Accès aux notifications → « Moto » (titre musique + guidage Waze).
   Si grisé : Paramètres > Applis > Moto > ⋮ > Autoriser les paramètres restreints.
2. Superposition → Moto (retour automatique après démarrage de ReFreezer).
3. Journal d'appels : toucher la case « 📞 Dernier appel ».

## v1.05
- Écran « Réglages » au démarrage tant qu'il manque une autorisation (lignes orange à toucher),
  y compris l'aide pas à pas pour « Autoriser les paramètres restreints ».
- Rouvrir les réglages : appui long sur le titre de la musique (accueil).

## v1.06
- 4 styles : Classique, Cockpit, Néon, Plein soleil — proposés au premier démarrage.
- Bouton ⚙ en haut de l'accueil : style + autorisations, modifiables à tout moment.

## v1.08
- Réglages redessinés : aperçus miniatures des 4 styles, autorisations en interrupteurs.
- Bouton « TOUT AUTORISER » qui enchaîne toutes les demandes.

## v1.09
- ▶ sur l'accueil : relance ReFreezer en arrière-plan sans l'ouvrir (ouverture seulement en dernier recours).
- « Titre & Waze » bloqué : ouvre d'abord Paramètres > Applis > Moto (paramètres restreints),
  puis l'accès aux notifications s'ouvre tout seul au retour.

## v1.10
- Case WAZE : appui = Waze + Moto en écran partagé (appui long = Waze plein écran).
- Mode compact automatique en écran partagé : titre + ⏮ ▶ ⏭, dernier appel, NRJ, FUN, ⚙.

## v1.11
- Corrige ReFreezer bloqué à 0:00 : plus aucune commande envoyée à ReFreezer fermé ;
  Moto l'ouvre, attend qu'il soit chargé, lance UNE fois, puis revient.
- Style Néon → Cyberpunk (jaune néon, cyan, rouge, coins coupés).

## v1.12
- Nouvelle icône : bouton lecture orange avec l'avant d'un roadster, fond noir.

## v1.13
- L'appli s'appelle maintenant RidePlay (nom sous l'icône, accueil, notification, réglages).
