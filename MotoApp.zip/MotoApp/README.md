# Appli Moto

Écran d'accueil :
- Haut (rectangle) : MUSIQUE → gros boutons Précédent / Suivant / Pause pour ReFreezer
- CONTACTS → 6 favoris (case vide = choisir, appui = appeler, appui long = changer)
- WAZE → lance Waze
- NRJ / FUN RADIO → lecture directe, ré-appui = stop (continue pendant Waze)

## Compiler l'APK

Option A — Android Studio (PC) : Fichier > Ouvrir > dossier MotoApp, puis Build > Build APK(s).
Brancher le téléphone en USB (débogage USB activé) et cliquer ▶ Run.

Option B — sans PC (GitHub) : créer un dépôt GitHub, y envoyer le contenu du dossier,
onglet Actions > "Build APK" > télécharger l'artefact moto-apk, puis l'installer sur le téléphone
(autoriser les "sources inconnues").

## À modifier si besoin
- Flux radio : app/src/main/java/com/moto/app/RadioService.kt (objet Radios)
- Couleurs / nom de paquet ReFreezer : Ui.kt
