# Appli Moto — v1.01

## Nouveautés
- MUSIQUE : démarre ReFreezer tout seul et revient sur Moto ; titre, artiste, temps, barre de progression ; bouton 🔀 FAVORIS (aléatoire).
- CONTACTS : logo 📱, jusqu'à 20 contacts, cases qui se resserrent ; appui long = changer / monter / supprimer.
- RADIOS : « Recherche… », « En direct », « Reconnexion… », et affichage de l'erreur sur la case. Fun Radio : nouvelles adresses + suivi des redirections.

## Réglages à faire une fois (écran Musique, toucher le cadre du haut)
1. Accès aux notifications → activer « Moto » (pour titre/artiste/temps).
   Si c'est grisé : Paramètres > Applis > Moto > ⋮ > Autoriser les paramètres restreints, puis recommencer.
2. Superposition → autoriser Moto (pour le retour automatique après le démarrage de ReFreezer).

## Compiler
Remplacer MotoApp.zip sur GitHub : la compilation repart toute seule (onglet Actions).
