package com.moto.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.ScrollView

/**
 * Écran de configuration : une ligne par autorisation.
 * Orange = à faire (toucher), vert = OK. S'ouvre au démarrage tant qu'il manque quelque chose.
 * Accessible aussi par un appui long sur le titre de la musique (accueil).
 */
class SetupActivity : Activity() {

    companion object {
        private fun granted(ctx: Context, p: String) =
            ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

        fun notifOk(ctx: Context) =
            Build.VERSION.SDK_INT < 33 || granted(ctx, Manifest.permission.POST_NOTIFICATIONS)

        fun phoneOk(ctx: Context) =
            granted(ctx, Manifest.permission.CALL_PHONE) && granted(ctx, Manifest.permission.READ_CALL_LOG)

        fun listenerOk(ctx: Context) = ctx.hasListenerAccess()

        /** « Paramètres restreints » (Android 13+, applis installées hors Play Store). */
        fun restrictedOk(ctx: Context): Boolean {
            if (Build.VERSION.SDK_INT < 33 || listenerOk(ctx)) return true
            return try {
                ctx.getSystemService(AppOpsManager::class.java).unsafeCheckOpNoThrow(
                    "android:access_restricted_settings", ctx.applicationInfo.uid, ctx.packageName
                ) == AppOpsManager.MODE_ALLOWED
            } catch (e: Exception) {
                false
            }
        }

        fun overlayOk(ctx: Context) = Settings.canDrawOverlays(ctx)

        fun batteryOk(ctx: Context) =
            ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)

        fun allOk(ctx: Context) =
            notifOk(ctx) && phoneOk(ctx) && listenerOk(ctx) && overlayOk(ctx) && batteryOk(ctx)

        fun isXiaomi() = Build.MANUFACTURER.lowercase() in setOf("xiaomi", "redmi", "poco")
    }

    private lateinit var list: LinearLayout
    private val prefs by lazy { getSharedPreferences("setup", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = vbox()

        root.addFullWidth(label(26f, Color.WHITE, bold = true).apply { text = "⚙  Réglages de Moto"; maxLines = 1 })
        root.addFullWidth(label(16f, Color.parseColor("#BBBBBB")).apply {
            text = "Touche chaque ligne ❌ orange, autorise, puis reviens ici."
        })

        list = vbox()
        val scroll = ScrollView(this).apply { addView(list) }
        root.addWeighted(scroll, 1f)

        val bottom = hbox()
        bottom.addWeighted(bigButton("Ne plus\ndemander", COLOR_GREY, 18f) {
            prefs.edit().putBoolean("noAsk", true).apply()
            finish()
        }, 1f)
        bottom.addWeighted(bigButton("✓ CONTINUER", COLOR_CONTACTS, 24f) { finish() }, 1.4f)
        root.addView(bottom, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(100)))

        setupScreen(root)
    }

    override fun onResume() {
        super.onResume()
        rebuild()
    }

    private fun rebuild() {
        list.removeAllViews()

        row("🔔  Notifications", "radio dans la barre de notification", notifOk(this)) {
            if (Build.VERSION.SDK_INT >= 33) ask(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        row("📞  Appels + journal d'appels", "appeler d'un appui, afficher le dernier appel", phoneOk(this)) {
            ask(arrayOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_CALL_LOG), 2)
        }
        row("🎵  Accès aux notifications", "titre / artiste / temps + guidage Waze", listenerOk(this)) {
            if (!restrictedOk(this)) toast("Si Android affiche « Paramètre restreint » : OK, puis reviens et touche la ligne 🔓")
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        if (Build.VERSION.SDK_INT >= 33) {
            row("🔓  Paramètres restreints", "débloque la ligne 🎵 au-dessus", restrictedOk(this)) {
                showRestrictedHelp()
            }
        }
        row("🪟  Superposition", "retour auto sur Moto après ReFreezer", overlayOk(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        row("🔋  Batterie sans restriction", "la radio ne se coupe pas écran éteint", batteryOk(this)) {
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        if (isXiaomi()) {
            row("🚀  Démarrage auto (Xiaomi)", "conseillé : activer « Moto » dans la liste", null) {
                try {
                    startActivity(Intent().setComponent(ComponentName(
                        "com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"
                    )))
                } catch (e: Exception) {
                    openAppDetails()
                }
            }
        }
    }

    /** Une ligne : vert si OK, orange si à faire, gris si on ne peut pas vérifier. */
    private fun row(title: String, desc: String, ok: Boolean?, action: () -> Unit) {
        val (mark, color) = when (ok) {
            true -> "✅" to Color.parseColor("#2E7D32")
            false -> "❌" to Color.parseColor("#E65100")
            null -> "➖" to COLOR_GREY
        }
        val b = bigButton(twoLine("$mark  $title", desc, 0.62f), color, 21f) { action() }
        list.addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(105)).apply {
            setMargins(dp(5), dp(5), dp(5), dp(5))
        })
    }

    private fun showRestrictedHelp() {
        AlertDialog.Builder(this)
            .setTitle("🔓 Paramètres restreints")
            .setMessage(
                "Android bloque cet accès pour les applis installées hors Play Store.\n\n" +
                    "1. Touche d'abord la ligne 🎵 et essaie d'activer Moto (Android refuse : normal).\n" +
                    "2. Reviens ici et touche OUVRIR.\n" +
                    "3. En haut à droite : ⋮ → « Autoriser les paramètres restreints ».\n" +
                    "4. Reviens ici et retouche la ligne 🎵 : ça passe."
            )
            .setPositiveButton("OUVRIR") { _, _ -> openAppDetails() }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun openAppDetails() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    /** Demande une permission ; si Android ne veut plus afficher la question, ouvre la page de l'appli. */
    private fun ask(perms: Array<String>, code: Int) {
        val askedBefore = prefs.getBoolean("asked$code", false)
        val blocked = askedBefore && perms.none { shouldShowRequestPermissionRationale(it) } &&
            perms.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (blocked) {
            toast("Autorise-le dans « Autorisations » de l'appli")
            openAppDetails()
        } else {
            prefs.edit().putBoolean("asked$code", true).apply()
            requestPermissions(perms, code)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        rebuild()
    }
}
