package com.moto.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.TextUtils
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

// ---------- Réglages faciles à modifier ----------
const val REFREEZER_PKG = "r.r.refreezer"
const val WAZE_PKG = "com.waze"

val COLOR_MUSIC = Color.parseColor("#6A1B9A")
val COLOR_MUSIC_DARK = Color.parseColor("#4A148C")
val COLOR_CONTACTS = Color.parseColor("#2E7D32")
val COLOR_CONTACTS_DARK = Color.parseColor("#1B5E20")
val COLOR_WAZE = Color.parseColor("#0277BD")
val COLOR_NRJ = Color.parseColor("#C62828")
val COLOR_FUN = Color.parseColor("#EF6C00")
val COLOR_FAV = Color.parseColor("#F9A825")
val COLOR_GREY = Color.parseColor("#424242")
// -------------------------------------------------

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun Context.toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

/** Gros bouton coloré, coins arrondis, vibration au toucher (utile avec des gants). */
fun Context.bigButton(text: CharSequence, color: Int, textSp: Float = 32f, onClick: (View) -> Unit): TextView =
    TextView(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        textSize = textSp
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(8), dp(8), dp(8), dp(8))
        val shape = GradientDrawable().apply { setColor(color); cornerRadius = dp(28).toFloat() }
        background = RippleDrawable(ColorStateList.valueOf(0x66FFFFFF), shape, null)
        isClickable = true
        setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            onClick(it)
        }
    }

/** Texte simple centré. */
fun Context.label(sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
    textSize = sp
    setTextColor(color)
    gravity = Gravity.CENTER
    maxLines = 2
    ellipsize = TextUtils.TruncateAt.END
    if (bold) typeface = Typeface.DEFAULT_BOLD
}

/** Gros titre + petite ligne dessous. */
fun twoLine(main: String, sub: String, ratio: Float = 0.55f): CharSequence = SpannableStringBuilder(main).apply {
    if (sub.isNotEmpty()) {
        append("\n")
        val start = length
        append(sub)
        setSpan(RelativeSizeSpan(ratio), start, length, 0)
    }
}

fun Context.vbox() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
fun Context.hbox() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

fun LinearLayout.addWeighted(v: View, weight: Float) {
    val m = context.dp(5)
    val lp = if (orientation == LinearLayout.VERTICAL)
        LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, weight)
    else
        LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, weight)
    lp.setMargins(m, m, m, m)
    addView(v, lp)
}

fun LinearLayout.addFullWidth(v: View) =
    addView(v, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

/** Écran noir, toujours allumé, utilisable même verrouillé. */
fun Activity.setupScreen(root: View) {
    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    window.statusBarColor = Color.BLACK
    window.navigationBarColor = Color.BLACK
    if (Build.VERSION.SDK_INT >= 27) setShowWhenLocked(true)
    root.setBackgroundColor(Color.BLACK)
    root.setPadding(dp(4), dp(4), dp(4), dp(4))
    setContentView(root)
}

/** Trouve une appli par nom de paquet, sinon par son nom affiché. */
fun Context.findPackage(pkg: String, labelHint: String): String? {
    val pm = packageManager
    if (pm.getLaunchIntentForPackage(pkg) != null) return pkg
    return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        .firstOrNull { it.loadLabel(pm).toString().contains(labelHint, ignoreCase = true) }
        ?.activityInfo?.packageName
}

fun Activity.launchApp(pkg: String, labelHint: String) {
    val intent = findPackage(pkg, labelHint)?.let { packageManager.getLaunchIntentForPackage(it) }
    if (intent != null) startActivity(intent)
    else toast("$labelHint introuvable sur le téléphone")
}

fun Context.hasListenerAccess(): Boolean =
    Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        ?.contains(packageName) == true

fun Context.rounded(color: Int) = GradientDrawable().apply {
    setColor(color)
    cornerRadius = dp(28).toFloat()
}
