package com.moto.app

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface

/** Style d'une case : fond, texte, contour (0 = pas de contour). */
data class Style(val fill: Int, val text: Int, val stroke: Int = Color.TRANSPARENT, val strokeDp: Int = 0)

class Theme(
    val id: String,
    val name: String,
    val desc: String,
    val bg: Int,            // fond d'écran
    val onBg: Int,          // texte posé sur le fond
    val lightBg: Boolean,   // fond clair → icônes système foncées
    private val fontFamily: String,
    val radiusDp: Int,
    val accent: Int,        // barre de progression, sélection
    val music: Style,       // carte musique / gros boutons musique
    val ctrl: Style,        // ⏮ ⏭
    val play: Style,        // ▶ ⏸
    val panel: Style,       // cadre « lecture en cours »
    val contacts: Style,
    val contactsSub: Style, // dernier appel / 2e teinte contacts
    val waze: Style,
    val nrj: Style,
    val funR: Style,
    val neutral: Style,     // retour, réglages
    val fav: Style,
    val chamfer: Boolean = false   // coins coupés en biais (Cyberpunk)
) {
    val font: Typeface get() = Typeface.create(fontFamily, Typeface.BOLD)
}

private fun c(s: String) = Color.parseColor(s)
private val W = Color.WHITE

object Themes {
    val CLASSIQUE = Theme(
        "classique", "Classique", "couleurs vives, fond noir",
        c("#000000"), W, false, "sans-serif", 28, c("#CE93D8"),
        music = Style(c("#6A1B9A"), W), ctrl = Style(c("#4A148C"), W), play = Style(c("#4A148C"), W),
        panel = Style(c("#1E1E1E"), W),
        contacts = Style(c("#2E7D32"), W), contactsSub = Style(c("#1B5E20"), W),
        waze = Style(c("#0277BD"), W), nrj = Style(c("#C62828"), W), funR = Style(c("#EF6C00"), W),
        neutral = Style(c("#424242"), W), fav = Style(c("#F9A825"), W)
    )

    private val cockpitPanel = Style(c("#1A1C20"), c("#F2F2F2"))
    private val cockpitDark = Style(c("#2C2F35"), c("#F2F2F2"))
    val COCKPIT = Theme(
        "cockpit", "Cockpit", "nuit, accent orange",
        c("#0E0F11"), c("#F2F2F2"), false, "sans-serif-condensed", 26, c("#FF6A13"),
        music = cockpitPanel, ctrl = cockpitDark, play = Style(c("#FF6A13"), c("#0E0F11")),
        panel = cockpitPanel,
        contacts = cockpitPanel, contactsSub = cockpitDark,
        waze = Style(c("#1A1C20"), c("#FF8A3D")),
        nrj = cockpitPanel, funR = cockpitPanel,
        neutral = cockpitDark, fav = Style(c("#FF6A13"), c("#0E0F11"))
    )

    // Cyberpunk 2077 : jaune néon, cyan, rouge, angles coupés
    private val night = c("#0A0A0F")
    private val plate = c("#14141C")
    private val cyY = c("#FCEE0A")
    private val cyC = c("#00F0FF")
    private val cyR = c("#FF003C")
    private val chrome = c("#EDEDED")
    val NEON = Theme(
        "neon", "Cyberpunk", "jaune néon, cyan, angles vifs",
        night, cyY, false, "sans-serif-condensed", 3, cyY,
        music = Style(plate, cyY, cyY, 1), ctrl = Style(night, cyC, cyC, 2),
        play = Style(cyY, night), panel = Style(plate, cyY, cyY, 1),
        contacts = Style(plate, chrome, cyC, 2), contactsSub = Style(cyC, night),
        waze = Style(plate, cyC, cyC, 2),
        nrj = Style(cyR, chrome), funR = Style(plate, cyY, cyR, 2),
        neutral = Style(plate, cyY, c("#3A3A46"), 2), fav = Style(cyY, night),
        chamfer = true
    )

    private val ink = c("#111111")
    private val soleilDark = Style(ink, W)
    private val soleilLight = Style(W, ink, ink, 4)
    val SOLEIL = Theme(
        "soleil", "Plein soleil", "jaune / noir, lisible au soleil",
        c("#FFD400"), ink, true, "sans-serif-black", 22, c("#FFD400"),
        music = soleilDark, ctrl = Style(W, ink), play = Style(c("#FFD400"), ink),
        panel = soleilDark,
        contacts = soleilLight, contactsSub = soleilDark,
        waze = soleilLight, nrj = soleilDark, funR = soleilDark,
        neutral = soleilDark, fav = soleilLight
    )

    val all = listOf(CLASSIQUE, COCKPIT, NEON, SOLEIL)
    fun byId(id: String?) = all.find { it.id == id } ?: CLASSIQUE
}

private fun uiPrefs(ctx: Context) = ctx.getSharedPreferences("ui", Context.MODE_PRIVATE)

/** Thème choisi (Classique par défaut). */
fun Context.ui(): Theme = Themes.byId(uiPrefs(this).getString("theme", null))

fun Context.setUiTheme(id: String) =
    uiPrefs(this).edit().putString("theme", id).putBoolean("chosen", true).apply()

fun Context.themeChosen() = uiPrefs(this).getBoolean("chosen", false)
fun Context.markThemeChosen() = uiPrefs(this).edit().putBoolean("chosen", true).apply()

/** Même couleur, autre transparence (texte secondaire). */
fun withAlpha(color: Int, alpha: Int) = (color and 0x00FFFFFF) or (alpha shl 24)
