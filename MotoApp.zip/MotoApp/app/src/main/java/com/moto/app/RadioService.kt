package com.moto.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

data class Radio(val id: String, val name: String, val urls: List<String>)

/** Flux radio : plusieurs adresses par radio, essayées dans l'ordre. */
object Radios {
    val NRJ = Radio(
        "nrj", "NRJ", listOf(
            "https://cdn.nrjaudio.fm/audio1/fr/30001/mp3_128.mp3?origine=fluxradios",
            "http://cdn.nrjaudio.fm/audio1/fr/30001/mp3_128.mp3?origine=fluxradios"
        )
    )
    val FUN = Radio(
        "fun", "FUN RADIO", listOf(
            "https://icecast.funradio.fr/fun-1-44-128",
            "http://icecast.funradio.fr/fun-1-44-128",
            "http://streamer-02.rtl.fr/fun-1-44-128"
        )
    )
    fun byId(id: String?) = listOf(NRJ, FUN).find { it.id == id }
}

enum class RadioState { CONNECTING, PLAYING, RECONNECTING }

/** Joue la radio en arrière-plan (continue pendant Waze, écran éteint, etc.). */
class RadioService : Service(), AudioManager.OnAudioFocusChangeListener {

    companion object {
        var current: Radio? = null
            private set
        var state = RadioState.CONNECTING
            private set
        var lastError: Pair<Radio, String>? = null
            private set
        var onChange: (() -> Unit)? = null

        fun play(ctx: Context, r: Radio) {
            current = r
            state = RadioState.CONNECTING
            lastError = null
            ctx.startForegroundService(Intent(ctx, RadioService::class.java).putExtra("id", r.id))
        }

        fun stop(ctx: Context) {
            if (current == null) return
            current = null
            ctx.startService(Intent(ctx, RadioService::class.java).setAction("stop"))
        }
    }

    private var player: MediaPlayer? = null
    private var focusReq: AudioFocusRequest? = null
    private var gen = 0            // invalide les anciennes tentatives
    private var retries = 0
    private var everPlayed = false
    private val handler = Handler(Looper.getMainLooper())
    private val am by lazy { getSystemService(AudioManager::class.java) }
    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    override fun onBind(intent: Intent?) = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "stop") { shutdown(); return START_NOT_STICKY }

        val r = Radios.byId(intent?.getStringExtra("id"))
        startFg(r?.name ?: "Radio")
        if (r == null) { shutdown(); return START_NOT_STICKY }
        if (!requestFocus()) { error(r, "Son occupé par une autre appli"); return START_NOT_STICKY }

        current = r
        retries = 0
        everPlayed = false
        connect(r)
        return START_NOT_STICKY
    }

    // ---------- Connexion ----------

    private fun connect(r: Radio) {
        releasePlayer()
        val g = ++gen
        setState(if (everPlayed) RadioState.RECONNECTING else RadioState.CONNECTING)
        Thread {
            var err = "Flux introuvable"
            var url: String? = null
            for (u in r.urls) {
                try { url = resolve(u); break } catch (e: Exception) { err = describe(e) }
            }
            handler.post {
                if (g != gen || current != r) return@post
                val ok = url
                if (ok == null) fail(r, err) else prepare(r, ok, g)
            }
        }.start()
    }

    /** Suit les redirections (http → https) que le lecteur Android ne suit pas tout seul. */
    private fun resolve(start: String): String {
        var url = start
        repeat(6) {
            val c = (URL(url).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = 7000
                readTimeout = 7000
                setRequestProperty("User-Agent", "MotoApp/1.01")
                setRequestProperty("Icy-MetaData", "0")
            }
            try {
                val code = c.responseCode
                when (code) {
                    in 200..299 -> return url
                    in 300..399 -> {
                        val loc = c.getHeaderField("Location") ?: throw IOException("redirection vide")
                        url = URL(URL(url), loc).toString()
                    }
                    else -> throw IOException("HTTP $code")
                }
            } finally {
                c.disconnect()
            }
        }
        throw IOException("trop de redirections")
    }

    private fun describe(e: Exception) = when (e) {
        is UnknownHostException -> "Pas de réseau"
        is SocketTimeoutException -> "Réseau trop lent"
        else -> "Flux introuvable" + (e.message?.let { " ($it)" } ?: "")
    }

    private val prepareTimeout = Runnable { current?.let { fail(it, "Réseau trop lent") } }

    private fun prepare(r: Radio, url: String, g: Int) {
        try {
            player = MediaPlayer().apply {
                setAudioAttributes(attrs)
                setWakeMode(this@RadioService, PowerManager.PARTIAL_WAKE_LOCK)
                setDataSource(url)
                setOnPreparedListener {
                    if (g == gen) {
                        handler.removeCallbacks(prepareTimeout)
                        it.start()
                        everPlayed = true
                        retries = 0
                        setState(RadioState.PLAYING)
                    }
                }
                setOnErrorListener { _, what, extra ->
                    if (g == gen) fail(r, "Lecture impossible ($what/$extra)")
                    true
                }
                setOnCompletionListener { if (g == gen) fail(r, "Flux coupé") }
                prepareAsync()
            }
            handler.postDelayed(prepareTimeout, 15000)
        } catch (e: Exception) {
            fail(r, describe(e))
        }
    }

    /** Échec : on réessaie, puis on affiche l'erreur sur la case. */
    private fun fail(r: Radio, msg: String) {
        handler.removeCallbacks(prepareTimeout)
        releasePlayer()
        gen++
        val max = if (everPlayed) 10 else 2   // coupure en route : on insiste plus
        if (retries++ < max) {
            setState(if (everPlayed) RadioState.RECONNECTING else RadioState.CONNECTING)
            handler.postDelayed({ if (current == r) connect(r) }, 3000)
        } else {
            error(r, msg)
        }
    }

    private fun error(r: Radio, msg: String) {
        lastError = r to msg
        toast("${r.name} : $msg")
        shutdown()
    }

    // ---------- Son ----------

    private fun requestFocus(): Boolean {
        val req = focusReq ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener(this)
            .build().also { focusReq = it }
        return am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    override fun onAudioFocusChange(change: Int) {
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> shutdown()                  // ReFreezer démarre
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {                 // appel
                handler.removeCallbacksAndMessages(null); gen++; releasePlayer()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> player?.setVolume(0.3f, 0.3f) // Waze parle
            AudioManager.AUDIOFOCUS_GAIN -> {
                val p = player
                if (p == null) current?.let { retries = 0; connect(it) } else p.setVolume(1f, 1f)
            }
        }
    }

    // ---------- État / notification ----------

    private fun setState(s: RadioState) {
        state = s
        current?.let { getSystemService(NotificationManager::class.java).notify(1, buildNotif(it.name)) }
        onChange?.invoke()
    }

    private fun statusText() = when (state) {
        RadioState.CONNECTING -> "Recherche…"
        RadioState.RECONNECTING -> "Reconnexion…"
        RadioState.PLAYING -> "En direct"
    }

    private fun buildNotif(title: String): Notification {
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, RadioService::class.java).setAction("stop"), PendingIntent.FLAG_IMMUTABLE
        )
        val openPi = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, "radio")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title)
            .setContentText(statusText())
            .setContentIntent(openPi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_media_pause), "STOP", stopPi
                ).build()
            )
            .build()
    }

    private fun startFg(title: String) {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("radio", "Radio", NotificationManager.IMPORTANCE_LOW))
        val n = buildNotif(title)
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(1, n)
    }

    private fun releasePlayer() {
        player?.release()
        player = null
    }

    private fun shutdown() {
        handler.removeCallbacksAndMessages(null)
        gen++
        releasePlayer()
        focusReq?.let { am.abandonAudioFocusRequest(it) }
        current = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        onChange?.invoke()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        releasePlayer()
        super.onDestroy()
    }
}
