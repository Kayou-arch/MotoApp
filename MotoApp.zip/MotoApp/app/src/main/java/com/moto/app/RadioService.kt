package com.moto.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager

data class Radio(val id: String, val name: String, val url: String)

/** Flux radio : à vérifier / remplacer si un flux ne marche plus. */
object Radios {
    val NRJ = Radio("nrj", "NRJ", "https://cdn.nrjaudio.fm/audio1/fr/30001/mp3_128.mp3?origine=fluxradios")
    val FUN = Radio("fun", "FUN RADIO", "http://streamer-02.rtl.fr/fun-1-44-128")
    fun byId(id: String?) = listOf(NRJ, FUN).find { it.id == id }
}

/** Joue la radio en arrière-plan (continue pendant Waze, écran éteint, etc.). */
class RadioService : Service(), AudioManager.OnAudioFocusChangeListener {

    companion object {
        var current: Radio? = null
            private set
        var onChange: (() -> Unit)? = null

        fun play(ctx: Context, r: Radio) {
            current = r
            ctx.startForegroundService(Intent(ctx, RadioService::class.java).putExtra("id", r.id))
        }

        fun stop(ctx: Context) {
            if (current == null) return
            current = null
            ctx.startService(Intent(ctx, RadioService::class.java).setAction("stop"))
        }
    }

    private var player: MediaPlayer? = null
    private var focusReq: AudioFocusRequest? = null
    private var retries = 0
    private val handler = Handler(Looper.getMainLooper())
    private val am by lazy { getSystemService(AudioManager::class.java) }
    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    override fun onBind(intent: Intent?) = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "stop") { shutdown(); return START_NOT_STICKY }

        val r = Radios.byId(intent?.getStringExtra("id"))
        goForeground(r?.name ?: "Radio")
        if (r == null || !requestFocus()) { shutdown(); return START_NOT_STICKY }

        current = r
        retries = 0
        startPlayer(r)
        onChange?.invoke()
        return START_NOT_STICKY
    }

    private fun startPlayer(r: Radio) {
        player?.release()
        player = null
        try {
            player = MediaPlayer().apply {
                setAudioAttributes(attrs)
                setWakeMode(this@RadioService, PowerManager.PARTIAL_WAKE_LOCK)
                setDataSource(r.url)
                setOnPreparedListener { it.start(); retries = 0 }
                setOnErrorListener { _, _, _ -> retry(); true }
                setOnCompletionListener { retry() } // flux coupé (tunnel, zone blanche…)
                prepareAsync()
            }
        } catch (e: Exception) {
            retry()
        }
    }

    /** Reconnexion automatique si le réseau saute. */
    private fun retry() {
        val r = current ?: return
        if (retries++ < 10) {
            handler.postDelayed({ if (current == r) startPlayer(r) }, 3000)
        } else shutdown()
    }

    private fun requestFocus(): Boolean {
        val req = focusReq ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener(this)
            .build().also { focusReq = it }
        return am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    override fun onAudioFocusChange(change: Int) {
        when (change) {
            // Une autre appli joue de la musique (ReFreezer) → on arrête
            AudioManager.AUDIOFOCUS_LOSS -> shutdown()
            // Appel téléphonique → pause, puis reprise après
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> { player?.release(); player = null }
            // Instruction Waze → volume baissé
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> player?.setVolume(0.3f, 0.3f)
            AudioManager.AUDIOFOCUS_GAIN -> {
                val p = player
                if (p == null) current?.let { startPlayer(it) } else p.setVolume(1f, 1f)
            }
        }
    }

    private fun goForeground(title: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("radio", "Radio", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, RadioService::class.java).setAction("stop"), PendingIntent.FLAG_IMMUTABLE
        )
        val openPi = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "radio")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title)
            .setContentText("En lecture")
            .setContentIntent(openPi)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_media_pause), "STOP", stopPi
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(1, n)
        }
    }

    private fun shutdown() {
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        focusReq?.let { am.abandonAudioFocusRequest(it) }
        current = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        onChange?.invoke()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        super.onDestroy()
    }
}
