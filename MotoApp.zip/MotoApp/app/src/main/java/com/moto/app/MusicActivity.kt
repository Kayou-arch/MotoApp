package com.moto.app

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

/**
 * Écran musique : titre / artiste / temps + gros boutons.
 * Démarre ReFreezer tout seul s'il n'est pas lancé, puis revient ici.
 */
class MusicActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var titleTv: TextView
    private lateinit var artistTv: TextView
    private lateinit var timeTv: TextView
    private lateinit var hintTv: TextView
    private lateinit var progress: ProgressBar
    private lateinit var playBtn: TextView

    private val pkg by lazy { findPackage(REFREEZER_PKG, "refreezer") }
    private var resumedNow = false

    // Démarrage automatique de ReFreezer
    private var starting = false
    private var startDeadline = 0L
    private var nextPlayAt = 0L
    private var playTries = 0
    private var favAfterStart = false

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        RadioService.stop(this) // coupe la radio pour laisser la place à la musique

        val root = vbox()

        // Cadre « lecture en cours »
        val card = vbox().apply {
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E1E1E")); cornerRadius = dp(24).toFloat()
            }
            isClickable = true
            setOnClickListener { onCardTap() }
        }
        titleTv = label(26f, Color.WHITE, bold = true)
        artistTv = label(20f, Color.parseColor("#BBBBBB"))
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progressTintList = ColorStateList.valueOf(Color.parseColor("#CE93D8"))
        }
        timeTv = label(18f, Color.WHITE)
        hintTv = label(14f, Color.parseColor("#FFB74D"))
        card.addFullWidth(titleTv)
        card.addFullWidth(artistTv)
        card.addView(progress, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(14)).apply {
            topMargin = dp(8)
        })
        card.addFullWidth(timeTv)
        card.addFullWidth(hintTv)
        root.addWeighted(card, 1.2f)

        // Précédent / Suivant
        val row = hbox()
        row.addWeighted(bigButton(twoLine("⏮", "PRÉC."), COLOR_MUSIC, 48f) { prev() }, 1f)
        row.addWeighted(bigButton(twoLine("⏭", "SUIV."), COLOR_MUSIC, 48f) { next() }, 1f)
        root.addWeighted(row, 1.6f)

        // Lecture / Pause
        playBtn = bigButton("⏯  LECTURE", COLOR_MUSIC_DARK, 28f) { playPause() }
        root.addWeighted(playBtn, 1f)

        // Favoris aléatoire / Retour
        val bottom = hbox()
        bottom.addWeighted(bigButton(twoLine("🔀 ★", "FAVORIS"), COLOR_FAV, 26f) { onFavorites() }, 1f)
        bottom.addWeighted(bigButton("◀ RETOUR", COLOR_GREY, 24f) { finish() }, 1f)
        root.addWeighted(bottom, 0.9f)

        setupScreen(root)
        if (savedInstanceState == null) startMusic()
        handler.post(ticker)
    }

    override fun onResume() { super.onResume(); resumedNow = true }
    override fun onPause() { super.onPause(); resumedNow = false }
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); super.onDestroy() }

    // ---------- Accès à ReFreezer ----------

    private fun controller(): MediaController? {
        val p = pkg ?: return null
        if (!hasListenerAccess()) return null
        return try {
            getSystemService(MediaSessionManager::class.java)
                .getActiveSessions(ComponentName(this, MediaListener::class.java))
                .firstOrNull { it.packageName == p }
        } catch (e: SecurityException) {
            null
        }
    }

    private fun startMusic() {
        if (!hasListenerAccess()) { mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY); return }
        val c = controller()
        when {
            c == null -> startReFreezer()
            c.playbackState?.state != PlaybackState.STATE_PLAYING -> c.transportControls.play()
        }
    }

    private fun startReFreezer() {
        if (pkg == null) { toast("ReFreezer introuvable sur le téléphone"); return }
        starting = true
        startDeadline = SystemClock.elapsedRealtime() + 20_000
        nextPlayAt = 0L
        playTries = 0
        titleTv.text = "Démarrage de ReFreezer…"
        artistTv.text = "retour automatique ici"
        launchApp(REFREEZER_PKG, "refreezer")
    }

    /** Revient sur l'écran Moto une fois ReFreezer lancé. */
    private fun comeBack() {
        if (resumedNow) return
        startActivity(
            Intent(this, MusicActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    private fun handleStart(c: MediaController?, now: Long) {
        if (now > startDeadline) {
            starting = false; favAfterStart = false
            comeBack()
            toast("ReFreezer ne répond pas : lance un titre dedans une fois")
            return
        }
        if (c == null) return
        if (nextPlayAt == 0L) { nextPlayAt = now + 1500; return }   // laisse ReFreezer se charger
        if (favAfterStart && now >= nextPlayAt) {
            starting = false; favAfterStart = false
            comeBack(); playFavorites()
            return
        }
        if (c.playbackState?.state == PlaybackState.STATE_PLAYING) {
            starting = false
            comeBack()
            return
        }
        if (now >= nextPlayAt && playTries < 5) {
            c.transportControls.play()   // insiste : c'est ce qui évitait le blocage à 0:00
            playTries++
            nextPlayAt = now + 2500
        }
    }

    // ---------- Affichage ----------

    private fun tick() {
        val now = SystemClock.elapsedRealtime()
        val c = controller()
        if (starting) handleStart(c, now)
        render(c, now)
    }

    private fun render(c: MediaController?, now: Long) {
        if (!hasListenerAccess()) {
            titleTv.text = "ReFreezer"
            artistTv.text = ""
            timeTv.text = ""
            progress.progress = 0
            hintTv.text = "👆 Toucher ici pour afficher titre / artiste / temps"
            playBtn.text = "⏯  PAUSE / LECTURE"
            return
        }
        hintTv.text = if (!Settings.canDrawOverlays(this))
            "👆 Toucher ici : autoriser la superposition (retour auto)" else ""

        if (c == null) {
            if (!starting) {
                titleTv.text = "ReFreezer arrêté"
                artistTv.text = "LECTURE pour démarrer"
            }
            timeTv.text = ""
            progress.progress = 0
            playBtn.text = "▶  LECTURE"
            return
        }

        val md = c.metadata
        val st = c.playbackState
        val playing = st?.state == PlaybackState.STATE_PLAYING
        titleTv.text = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "—"
        artistTv.text = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""

        val dur = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        var pos = st?.position ?: 0L
        if (playing && st != null) pos += ((now - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
        if (dur > 0) pos = pos.coerceIn(0L, dur)

        timeTv.text = when {
            st?.state == PlaybackState.STATE_BUFFERING -> "⏳ Chargement…"
            dur > 0 -> "${fmt(pos)}  /  ${fmt(dur)}"
            else -> fmt(pos)
        }
        progress.progress = if (dur > 0) (pos * 1000 / dur).toInt() else 0
        playBtn.text = if (playing) "⏸  PAUSE" else "▶  LECTURE"
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    // ---------- Boutons ----------

    private fun prev() {
        controller()?.transportControls?.skipToPrevious() ?: mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    }

    private fun next() {
        controller()?.transportControls?.skipToNext() ?: mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
    }

    private fun playPause() {
        if (!hasListenerAccess()) { mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE); return }
        val c = controller()
        when {
            c == null -> startReFreezer()
            c.playbackState?.state == PlaybackState.STATE_PLAYING -> c.transportControls.pause()
            else -> c.transportControls.play()
        }
    }

    private fun onCardTap() {
        when {
            !hasListenerAccess() -> {
                toast("Active « Moto ». Si c'est grisé : Paramètres > Applis > Moto > ⋮ > Autoriser les paramètres restreints")
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
            !Settings.canDrawOverlays(this) ->
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            else -> launchApp(REFREEZER_PKG, "refreezer")
        }
    }

    // ---------- Favoris aléatoire ----------

    private fun onFavorites() {
        if (!hasListenerAccess()) { toast("Autorise d'abord l'accès : touche le cadre du haut"); return }
        if (controller() == null) { favAfterStart = true; startReFreezer(); return }
        playFavorites()
    }

    private fun playFavorites() {
        val p = pkg ?: return
        titleTv.text = "🔀 Recherche des favoris…"
        FavoritesFinder(this, p) found@{ mediaId ->
            val c = controller() ?: run { toast("ReFreezer ne répond pas"); return@found }
            shuffleOn(c)
            if (mediaId != null) {
                c.transportControls.playFromMediaId(mediaId, null)
                // relance l'aléatoire une fois la liste chargée, et saute au hasard
                handler.postDelayed({ controller()?.let { shuffleOn(it); it.transportControls.skipToNext() } }, 2500)
                toast("🔀 Favoris en aléatoire")
            } else {
                c.transportControls.play()
                toast("Favoris non trouvés : aléatoire sur la liste en cours")
            }
        }.start()
    }

    /** Active l'aléatoire (commande standard comprise par ReFreezer / audio_service). */
    private fun shuffleOn(c: MediaController) {
        c.transportControls.sendCustomAction(
            "android.support.v4.media.session.action.SET_SHUFFLE_MODE",
            Bundle().apply { putInt("android.support.v4.media.session.action.ARGUMENT_SHUFFLE_MODE", 1) }
        )
    }

    private fun mediaKey(code: Int) {
        val am = getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }
}
