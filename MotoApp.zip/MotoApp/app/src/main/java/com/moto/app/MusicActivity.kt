package com.moto.app

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

/**
 * Écran musique détaillé. Démarre ReFreezer tout seul s'il n'est pas lancé.
 * autoClose = true : après le démarrage, retour direct à l'accueil.
 */
class MusicActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var titleTv: TextView
    private lateinit var artistTv: TextView
    private lateinit var timeTv: TextView
    private lateinit var hintTv: TextView
    private lateinit var progress: ProgressBar
    private lateinit var playBtn: TextView

    private var resumedNow = false
    private var autoClose = false

    private var starting = false
    private var startDeadline = 0L
    private var nextPlayAt = 0L
    private var playTries = 0
    private var favAfterStart = false

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        autoClose = intent.getBooleanExtra("autoClose", false)
        val t = ui()

        val root = vbox()

        val card = vbox().apply {
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = shape(t.panel, t)
            isClickable = true
            setOnClickListener { onCardTap() }
        }
        titleTv = label(26f, t.panel.text, bold = true)
        artistTv = label(20f, withAlpha(t.panel.text, 0xB8))
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progressTintList = ColorStateList.valueOf(t.accent)
        }
        timeTv = label(18f, t.panel.text)
        hintTv = label(14f, Color.parseColor("#FFB74D"))
        card.addFullWidth(titleTv)
        card.addFullWidth(artistTv)
        card.addView(progress, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(14)).apply {
            topMargin = dp(8)
        })
        card.addFullWidth(timeTv)
        card.addFullWidth(hintTv)
        root.addWeighted(card, 1.2f)

        val row = hbox()
        row.addWeighted(bigButton(twoLine("⏮", "PRÉC."), t.music, 48f) { prev() }, 1f)
        row.addWeighted(bigButton(twoLine("⏭", "SUIV."), t.music, 48f) { next() }, 1f)
        root.addWeighted(row, 1.6f)

        playBtn = bigButton("▶  LECTURE", t.play, 28f) { playPause() }
        root.addWeighted(playBtn, 1f)

        val bottom = hbox()
        bottom.addWeighted(bigButton(twoLine("🔀 ★", "FAVORIS"), t.fav, 26f) { onFavorites() }, 1f)
        bottom.addWeighted(bigButton("◀ RETOUR", t.neutral, 24f) { finish() }, 1f)
        root.addWeighted(bottom, 0.9f)

        setupScreen(root)
        // Lance la musique, sauf si une radio est en train de jouer et qu'on vient juste regarder
        if (savedInstanceState == null && (autoClose || RadioService.current == null)) startMusic()
        handler.post(ticker)
    }

    override fun onResume() { super.onResume(); resumedNow = true }
    override fun onPause() { super.onPause(); resumedNow = false }
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); super.onDestroy() }

    // ---------- Démarrage auto de ReFreezer ----------

    private fun startMusic() {
        if (!hasListenerAccess()) { Music.mediaKey(this, KeyEvent.KEYCODE_MEDIA_PLAY); return }
        val c = Music.controller(this)
        when {
            c == null -> startReFreezer()
            !Music.isPlaying(c) -> c.transportControls.play()
        }
    }

    private fun startReFreezer() {
        if (Music.pkg(this) == null) { toast("ReFreezer introuvable sur le téléphone"); return }
        starting = true
        startDeadline = SystemClock.elapsedRealtime() + 20_000
        nextPlayAt = 0L
        playTries = 0
        titleTv.text = "Démarrage de ReFreezer…"
        artistTv.text = "retour automatique ici"
        launchApp(REFREEZER_PKG, "refreezer")
    }

    private fun comeBack() {
        if (autoClose) {
            // retour direct à l'accueil (ferme cet écran)
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            finish()
            return
        }
        if (resumedNow) return
        startActivity(
            Intent(this, MusicActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    private fun handleStart(c: MediaController?, now: Long) {
        if (now > startDeadline) {
            starting = false; favAfterStart = false
            toast("ReFreezer ne répond pas : lance un titre dedans une fois")
            comeBack()
            return
        }
        if (c == null) return
        if (nextPlayAt == 0L) { nextPlayAt = now + 1500; return }
        if (favAfterStart && now >= nextPlayAt) {
            starting = false; favAfterStart = false
            playFavorites()
            if (!autoClose) comeBack()
            return
        }
        if (Music.isPlaying(c)) {
            starting = false
            comeBack()
            return
        }
        if (now >= nextPlayAt && playTries < 5) {
            c.transportControls.play()
            playTries++
            nextPlayAt = now + 2500
        }
    }

    // ---------- Affichage ----------

    private fun tick() {
        val now = SystemClock.elapsedRealtime()
        val c = Music.controller(this)
        if (starting) handleStart(c, now)
        if (!isFinishing) render(c, now)
    }

    private fun render(c: MediaController?, now: Long) {
        if (!hasListenerAccess()) {
            titleTv.text = "ReFreezer"
            artistTv.text = ""
            timeTv.text = ""
            progress.progress = 0
            hintTv.text = "👆 Toucher ici pour afficher titre / artiste / temps"
            playBtn.text = "⏯  PAUSE / LECTURE"
            return
        }
        hintTv.text = if (!Settings.canDrawOverlays(this))
            "👆 Toucher ici : autoriser la superposition (retour auto)" else ""

        if (c == null) {
            if (!starting) {
                val last = Music.last(this)
                titleTv.text = last?.first ?: "ReFreezer arrêté"
                artistTv.text = last?.second ?: "LECTURE pour démarrer"
                timeTv.text = if (last != null) "Dernier écouté" else ""
            }
            progress.progress = 0
            playBtn.text = "▶  LECTURE"
            return
        }

        Music.remember(this, c)
        val md = c.metadata
        titleTv.text = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "—"
        artistTv.text = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val (pos, dur) = Music.position(c, now)
        timeTv.text = when {
            c.playbackState?.state == PlaybackState.STATE_BUFFERING -> "⏳ Chargement…"
            dur > 0 -> "${Music.fmt(pos)}  /  ${Music.fmt(dur)}"
            else -> Music.fmt(pos)
        }
        progress.progress = if (dur > 0) (pos * 1000 / dur).toInt() else 0
        playBtn.text = if (Music.isPlaying(c)) "⏸  PAUSE" else "▶  LECTURE"
    }

    // ---------- Boutons ----------

    private fun prev() {
        Music.controller(this)?.transportControls?.skipToPrevious()
            ?: Music.mediaKey(this, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    }

    private fun next() {
        Music.controller(this)?.transportControls?.skipToNext()
            ?: Music.mediaKey(this, KeyEvent.KEYCODE_MEDIA_NEXT)
    }

    private fun playPause() {
        if (!hasListenerAccess()) { Music.mediaKey(this, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE); return }
        val c = Music.controller(this)
        when {
            c == null -> startReFreezer()
            Music.isPlaying(c) -> c.transportControls.pause()
            else -> c.transportControls.play()
        }
    }

    private fun onCardTap() {
        when {
            !hasListenerAccess() -> {
                toast("Active « Moto ». Si c'est grisé : Paramètres > Applis > Moto > ⋮ > Autoriser les paramètres restreints")
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
            !Settings.canDrawOverlays(this) ->
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            else -> launchApp(REFREEZER_PKG, "refreezer")
        }
    }

    // ---------- Favoris aléatoire ----------

    private fun onFavorites() {
        if (!hasListenerAccess()) { toast("Autorise d'abord l'accès : touche le cadre du haut"); return }
        if (Music.controller(this) == null) { favAfterStart = true; startReFreezer(); return }
        playFavorites()
    }

    private fun playFavorites() {
        val p = Music.pkg(this) ?: return
        titleTv.text = "🔀 Recherche des favoris…"
        FavoritesFinder(applicationContext, p) found@{ mediaId ->
            val c = Music.controller(applicationContext) ?: run { toast("ReFreezer ne répond pas"); return@found }
            shuffleOn(c)
            if (mediaId != null) {
                c.transportControls.playFromMediaId(mediaId, null)
                handler.postDelayed({
                    Music.controller(applicationContext)?.let { shuffleOn(it); it.transportControls.skipToNext() }
                }, 2500)
                toast("🔀 Favoris en aléatoire")
            } else {
                c.transportControls.play()
                toast("Favoris non trouvés : aléatoire sur la liste en cours")
            }
        }.start()
    }

    private fun shuffleOn(c: MediaController) {
        c.transportControls.sendCustomAction(
            "android.support.v4.media.session.action.SET_SHUFFLE_MODE",
            Bundle().apply { putInt("android.support.v4.media.session.action.ARGUMENT_SHUFFLE_MODE", 1) }
        )
    }
}
