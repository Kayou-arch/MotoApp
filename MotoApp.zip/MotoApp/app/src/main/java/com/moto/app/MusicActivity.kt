package com.moto.app

import android.app.Activity
import android.media.AudioManager
import android.os.Bundle
import android.view.KeyEvent

/**
 * Gros boutons Précédent / Suivant / Pause qui pilotent ReFreezer
 * (ou n'importe quel lecteur actif) via les touches média d'Android.
 */
class MusicActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        RadioService.stop(this) // coupe la radio pour laisser la place à la musique

        val root = vbox()

        val row = hbox()
        row.addWeighted(bigButton("⏮\nPRÉC.", COLOR_MUSIC, 36f) {
            key(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
        }, 1f)
        row.addWeighted(bigButton("⏭\nSUIV.", COLOR_MUSIC, 36f) {
            key(KeyEvent.KEYCODE_MEDIA_NEXT)
        }, 1f)
        root.addWeighted(row, 2f)

        root.addWeighted(bigButton("⏯  PAUSE / LECTURE", COLOR_MUSIC_DARK, 28f) {
            key(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
        }, 1.2f)

        val bottom = hbox()
        bottom.addWeighted(bigButton("OUVRIR\nREFREEZER", COLOR_GREY, 22f) {
            launchApp(REFREEZER_PKG, "refreezer")
        }, 1f)
        bottom.addWeighted(bigButton("◀ RETOUR", COLOR_GREY, 24f) { finish() }, 1f)
        root.addWeighted(bottom, 0.8f)

        setupScreen(root)

        // Relance la musique en arrivant sur l'écran
        if (savedInstanceState == null) key(KeyEvent.KEYCODE_MEDIA_PLAY)
    }

    private fun key(code: Int) {
        val am = getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }
}
