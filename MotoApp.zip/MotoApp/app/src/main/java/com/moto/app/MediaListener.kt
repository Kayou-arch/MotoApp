package com.moto.app

import android.service.notification.NotificationListenerService

/** Vide : sa seule présence (une fois autorisée) permet de lire la lecture en cours. */
class MediaListener : NotificationListenerService()
