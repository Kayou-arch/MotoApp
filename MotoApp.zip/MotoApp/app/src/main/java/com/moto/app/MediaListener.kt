package com.moto.app

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Infos de navigation lues dans la notification de Waze. */
object Waze {
    var title: String? = null
    var text: String? = null
    var onChange: (() -> Unit)? = null
}

/**
 * Une fois autorisé (accès aux notifications), sert à :
 * - lire la lecture en cours de ReFreezer (titre / artiste / temps)
 * - lire la notification de guidage de Waze
 */
class MediaListener : NotificationListenerService() {

    override fun onListenerConnected() {
        try {
            activeNotifications
                ?.filter { it.packageName == WAZE_PKG }
                ?.maxByOrNull { it.postTime }
                ?.let { read(it) }
        } catch (_: Exception) {}
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == WAZE_PKG) read(sbn)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (sbn.packageName == WAZE_PKG) {
            Waze.title = null
            Waze.text = null
            Waze.onChange?.invoke()
        }
    }

    private fun read(sbn: StatusBarNotification) {
        val e = sbn.notification.extras
        Waze.title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.takeIf { it.isNotBlank() }
        Waze.text = (e.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: e.getCharSequence(Notification.EXTRA_TEXT))
            ?.toString()?.takeIf { it.isNotBlank() }
        Waze.onChange?.invoke()
    }
}
