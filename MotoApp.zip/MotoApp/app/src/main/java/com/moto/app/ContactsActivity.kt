package com.moto.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.text.TextUtils
import android.view.View
import android.widget.LinearLayout
import java.util.Collections

/**
 * Contacts favoris (jusqu'à 20). Les cases se resserrent toutes seules.
 * - Appui = appeler
 * - Appui long = changer / monter / supprimer
 * - Case « + AJOUTER » = ajouter un contact
 */
class ContactsActivity : Activity() {

    private data class Fav(val name: String, val num: String)

    companion object {
        const val MAX = 20
        const val REQ_ADD = 100
        const val REQ_REPLACE = 200
    }

    private val prefs by lazy { getSharedPreferences("contacts", MODE_PRIVATE) }
    private lateinit var grid: LinearLayout
    private var favs = mutableListOf<Fav>()
    private var pendingNumber: String? = null
    private val shades by lazy { listOf(ui().contacts, ui().contactsSub) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        favs = load()
        val root = vbox()
        grid = vbox()
        root.addWeighted(grid, 1f)
        root.addWeighted(bigButton("◀ RETOUR", ui().neutral, 24f) { finish() }, 0.13f)
        setupScreen(root)
        rebuild()
    }

    // ---------- Grille automatique ----------

    private fun rebuild() {
        grid.removeAllViews()
        val cells = favs.size + if (favs.size < MAX) 1 else 0
        val cols = if (cells <= 8) 2 else 3
        val rows = (cells + cols - 1) / cols
        val size = when {
            cols == 3 -> 18f
            rows <= 3 -> 26f
            rows == 4 -> 22f
            else -> 20f
        }
        for (r in 0 until rows) {
            val row = hbox()
            for (c in 0 until cols) {
                val i = r * cols + c
                val v: View = when {
                    i < favs.size -> bigButton(favs[i].name, shades[(r + c) % 2], size) { call(favs[i].num) }
                        .also { b ->
                            b.maxLines = 3
                            b.ellipsize = TextUtils.TruncateAt.END
                            b.setOnLongClickListener { edit(i); true }
                        }
                    i == favs.size && favs.size < MAX ->
                        bigButton(twoLine("+", "AJOUTER"), ui().neutral, size * 1.4f) { pick(REQ_ADD) }
                    else -> View(this)
                }
                row.addWeighted(v, 1f)
            }
            grid.addWeighted(row, 1f)
        }
    }

    private fun edit(i: Int) {
        AlertDialog.Builder(this)
            .setTitle(favs[i].name)
            .setItems(arrayOf("🔄  Changer de contact", "⬆  Monter d'une case", "🗑  Supprimer", "Annuler")) { _, which ->
                when (which) {
                    0 -> pick(REQ_REPLACE + i)
                    1 -> if (i > 0) { Collections.swap(favs, i, i - 1); save(); rebuild() }
                    2 -> { favs.removeAt(i); save(); rebuild() }
                }
            }
            .show()
    }

    // ---------- Choix du contact ----------

    private fun pick(req: Int) {
        startActivityForResult(Intent(Intent.ACTION_PICK, Phone.CONTENT_URI), req)
    }

    @Deprecated("API Activity classique")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        var fav: Fav? = null
        contentResolver.query(uri, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, null)?.use {
            if (it.moveToFirst()) fav = Fav(it.getString(0) ?: "?", it.getString(1) ?: return@use)
        }
        val f = fav ?: return
        when (requestCode) {
            REQ_ADD -> if (favs.size < MAX) favs.add(f)
            in REQ_REPLACE until REQ_REPLACE + MAX -> {
                val idx = requestCode - REQ_REPLACE
                if (idx < favs.size) favs[idx] = f
            }
        }
        save()
        rebuild()
    }

    // ---------- Sauvegarde ----------

    private fun load(): MutableList<Fav> {
        val raw = prefs.getString("list", null)
        if (raw == null) {
            // Reprise des 6 contacts de la v1.0
            val old = (0..5).mapNotNull { i ->
                val n = prefs.getString("name$i", null)
                val p = prefs.getString("num$i", null)
                if (n != null && p != null) Fav(n, p) else null
            }.toMutableList()
            favs = old
            save()
            return old
        }
        return raw.split("\n").filter { it.contains('\t') }.map {
            val (n, p) = it.split('\t', limit = 2)
            Fav(n, p)
        }.toMutableList()
    }

    private fun save() {
        val raw = favs.joinToString("\n") { "${it.name.replace('\t', ' ').replace('\n', ' ')}\t${it.num}" }
        prefs.edit().putString("list", raw).apply()
    }

    // ---------- Appel ----------

    private fun call(num: String) {
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num))))
        } else {
            pendingNumber = num
            requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), 42)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val num = pendingNumber ?: return
        pendingNumber = null
        val granted = grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
        if (!granted) toast("Sans permission : ouverture du clavier d'appel")
        val action = if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL
        startActivity(Intent(action, Uri.parse("tel:" + Uri.encode(num))))
    }
}
