package com.moto.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.widget.TextView
import android.widget.Toast

/**
 * 6 contacts favoris.
 * - Case vide : appui = choisir un contact.
 * - Case remplie : appui = appeler. Appui long = changer le contact.
 */
class ContactsActivity : Activity() {

    private val prefs by lazy { getSharedPreferences("contacts", MODE_PRIVATE) }
    private val buttons = arrayOfNulls<TextView>(6)
    private var pendingNumber: String? = null

    private val colors = listOf("#2E7D32", "#1B5E20", "#1B5E20", "#2E7D32", "#2E7D32", "#1B5E20")
        .map { Color.parseColor(it) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = vbox()

        for (r in 0..2) {
            val row = hbox()
            for (c in 0..1) {
                val i = r * 2 + c
                val b = bigButton("", colors[i], 26f) { onTap(i) }
                b.setOnLongClickListener { pick(i); true }
                b.maxLines = 3
                buttons[i] = b
                row.addWeighted(b, 1f)
            }
            root.addWeighted(row, 1f)
        }
        root.addWeighted(bigButton("◀ RETOUR", COLOR_GREY, 24f) { finish() }, 0.45f)

        setupScreen(root)
        refresh()
    }

    private fun refresh() {
        for (i in 0 until 6) {
            buttons[i]?.text = prefs.getString("name$i", null) ?: "+\nAjouter"
        }
    }

    private fun onTap(i: Int) {
        val num = prefs.getString("num$i", null)
        if (num == null) pick(i) else call(num)
    }

    private fun pick(i: Int) {
        startActivityForResult(Intent(Intent.ACTION_PICK, Phone.CONTENT_URI), i)
    }

    @Deprecated("API Activity classique")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || requestCode !in 0..5) return
        val uri = data?.data ?: return
        contentResolver.query(uri, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, null)?.use {
            if (it.moveToFirst()) {
                prefs.edit()
                    .putString("name$requestCode", it.getString(0))
                    .putString("num$requestCode", it.getString(1))
                    .apply()
            }
        }
        refresh()
    }

    private fun call(num: String) {
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num))))
        } else {
            pendingNumber = num
            requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), 42)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val num = pendingNumber ?: return
        pendingNumber = null
        val granted = grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
        if (!granted) Toast.makeText(this, "Sans permission : ouverture du clavier d'appel", Toast.LENGTH_SHORT).show()
        val action = if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL
        startActivity(Intent(action, Uri.parse("tel:" + Uri.encode(num))))
    }
}
