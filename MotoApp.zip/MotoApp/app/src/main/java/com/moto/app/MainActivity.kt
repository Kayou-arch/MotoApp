package com.moto.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var nrjBtn: TextView
    private lateinit var funBtn: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var dots = 0

    // Fait « vivre » les cases radio (Recherche. .. ...)
    private val ticker = object : Runnable {
        override fun run() {
            dots = (dots + 1) % 4
            refresh()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = vbox()

        root.addWeighted(bigButton(twoLine("♫  MUSIQUE", "ReFreezer"), COLOR_MUSIC, 36f) {
            startActivity(Intent(this, MusicActivity::class.java))
        }, 1f)

        val row1 = hbox()
        row1.addWeighted(bigButton(twoLine("📱", "CONTACTS"), COLOR_CONTACTS, 56f) {
            startActivity(Intent(this, ContactsActivity::class.java))
        }, 1f)
        row1.addWeighted(bigButton(twoLine("➤", "WAZE"), COLOR_WAZE, 56f) {
            launchApp(WAZE_PKG, "Waze")
        }, 1f)
        root.addWeighted(row1, 1.3f)

        val row2 = hbox()
        nrjBtn = bigButton("", COLOR_NRJ, 32f) { toggle(Radios.NRJ) }
        funBtn = bigButton("", COLOR_FUN, 32f) { toggle(Radios.FUN) }
        row2.addWeighted(nrjBtn, 1f)
        row2.addWeighted(funBtn, 1f)
        root.addWeighted(row2, 1.3f)

        setupScreen(root)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        RadioService.onChange = { refresh() }
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        RadioService.onChange = null
        handler.removeCallbacks(ticker)
    }

    private fun toggle(r: Radio) {
        if (RadioService.current == r) RadioService.stop(this) else RadioService.play(this, r)
        refresh()
    }

    private fun refresh() {
        label(nrjBtn, Radios.NRJ)
        label(funBtn, Radios.FUN)
    }

    private fun label(b: TextView, r: Radio) {
        val mine = RadioService.current == r
        val d = ".".repeat(dots)
        val err = RadioService.lastError?.takeIf { it.first == r }?.second
        val sub = when {
            mine && RadioService.state == RadioState.CONNECTING -> "⏳ Recherche$d"
            mine && RadioService.state == RadioState.RECONNECTING -> "⏳ Reconnexion$d"
            mine -> "🔊 En direct\n■ STOP"
            err != null -> "⚠ $err\nToucher = réessayer"
            else -> "▶ Écouter"
        }
        b.text = twoLine(r.name, sub)
        b.alpha = if (RadioService.current != null && !mine) 0.6f else 1f
    }
}
