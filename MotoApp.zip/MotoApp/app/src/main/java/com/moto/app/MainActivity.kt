package com.moto.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var nrjBtn: TextView
    private lateinit var funBtn: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = vbox()

        // Rectangle du haut : musique ReFreezer
        root.addWeighted(bigButton("♫  MUSIQUE\nReFreezer", COLOR_MUSIC, 36f) {
            startActivity(Intent(this, MusicActivity::class.java))
        }, 1f)

        // Ligne 1 : Contacts + Waze
        val row1 = hbox()
        row1.addWeighted(bigButton("☎\nCONTACTS", COLOR_CONTACTS, 30f) {
            startActivity(Intent(this, ContactsActivity::class.java))
        }, 1f)
        row1.addWeighted(bigButton("➤\nWAZE", COLOR_WAZE, 34f) {
            launchApp(WAZE_PKG, "Waze")
        }, 1f)
        root.addWeighted(row1, 1.3f)

        // Ligne 2 : NRJ + Fun Radio
        val row2 = hbox()
        nrjBtn = bigButton("", COLOR_NRJ, 30f) { toggle(Radios.NRJ) }
        funBtn = bigButton("", COLOR_FUN, 30f) { toggle(Radios.FUN) }
        row2.addWeighted(nrjBtn, 1f)
        row2.addWeighted(funBtn, 1f)
        root.addWeighted(row2, 1.3f)

        setupScreen(root)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        RadioService.onChange = { refresh() }
        refresh()
    }

    override fun onPause() {
        super.onPause()
        RadioService.onChange = null
    }

    private fun toggle(r: Radio) {
        if (RadioService.current == r) RadioService.stop(this) else RadioService.play(this, r)
        refresh()
    }

    private fun refresh() {
        label(nrjBtn, Radios.NRJ)
        label(funBtn, Radios.FUN)
    }

    private fun label(b: TextView, r: Radio) {
        val playing = RadioService.current == r
        b.text = if (playing) "${r.name}\n■ STOP" else "${r.name}\n▶"
        b.alpha = if (RadioService.current != null && !playing) 0.6f else 1f
    }
}
