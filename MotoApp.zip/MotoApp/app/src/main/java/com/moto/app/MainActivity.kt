package com.moto.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.CallLog
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private data class LastCall(val name: String, val num: String, val type: Int)

    private lateinit var mTitle: TextView
    private lateinit var mArtist: TextView
    private lateinit var mTime: TextView
    private lateinit var mPlay: TextView
    private lateinit var lastCallBtn: TextView
    private lateinit var wazeBtn: TextView
    private lateinit var nrjBtn: TextView
    private lateinit var funBtn: TextView

    private val handler = Handler(Looper.getMainLooper())
    private var dots = 0
    private var lastCall: LastCall? = null
    private var pendingNumber: String? = null
    private var appliedTheme = ""

    private val ticker = object : Runnable {
        override fun run() {
            dots = (dots + 1) % 4
            refreshMusic()
            refreshRadios()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val t = ui()
        appliedTheme = t.id
        val root = vbox()

        // ---------- Barre du haut : nom + ⚙ ----------
        val top = hbox().apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(label(18f, t.onBg, bold = true).apply {
            text = "MOTO"
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            letterSpacing = 0.18f
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply { marginStart = dp(12) })
        val gear = bigButton("⚙", t.neutral, 24f) {
            startActivity(Intent(this, SetupActivity::class.java))
        }.apply { contentDescription = "Paramètres"; setPadding(0, 0, 0, 0) }
        top.addView(gear, LinearLayout.LayoutParams(dp(68), LinearLayout.LayoutParams.MATCH_PARENT).apply {
            setMargins(dp(5), dp(3), dp(5), dp(3))
        })
        root.addView(top, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(56)))

        // ---------- Musique : lecture en cours + commandes ----------
        val card = vbox().apply { background = shape(t.music, t) }
        val info = vbox().apply {
            gravity = Gravity.CENTER
            isClickable = true
            setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                openMusic(autoClose = false)
            }
            // appui long sur le titre = réglages
            setOnLongClickListener {
                startActivity(Intent(this@MainActivity, SetupActivity::class.java)); true
            }
        }
        mTitle = label(24f, t.music.text, bold = true)
        mArtist = label(18f, withAlpha(t.music.text, 0xC0))
        mTime = label(16f, t.music.text)
        info.addFullWidth(mTitle)
        info.addFullWidth(mArtist)
        info.addFullWidth(mTime)
        card.addWeighted(info, 1f)

        val ctr = hbox()
        ctr.addWeighted(bigButton("⏮", t.ctrl, 40f) { mPrev() }, 1f)
        mPlay = bigButton("▶", t.play, 40f) { mPlayPause() }
        ctr.addWeighted(mPlay, 1f)
        ctr.addWeighted(bigButton("⏭", t.ctrl, 40f) { mNext() }, 1f)
        card.addWeighted(ctr, 0.9f)
        root.addWeighted(card, 1.35f)

        // ---------- Contacts (+ dernier appel) / Waze ----------
        val row1 = hbox()
        val cBox = vbox()
        cBox.addWeighted(bigButton(twoLine("📱", "CONTACTS"), t.contacts, 40f) {
            startActivity(Intent(this, ContactsActivity::class.java))
        }, 1.5f)
        lastCallBtn = bigButton("", t.contactsSub, 20f) { onLastCall() }
        lastCallBtn.maxLines = 2
        cBox.addWeighted(lastCallBtn, 1f)
        row1.addWeighted(cBox, 1f)

        wazeBtn = bigButton("", t.waze, 56f) { launchApp(WAZE_PKG, "Waze") }
        wazeBtn.maxLines = 7
        row1.addWeighted(wazeBtn, 1f)
        root.addWeighted(row1, 1.25f)

        // ---------- Radios ----------
        val row2 = hbox()
        nrjBtn = bigButton("", t.nrj, 30f) { toggle(Radios.NRJ) }
        funBtn = bigButton("", t.funR, 30f) { toggle(Radios.FUN) }
        row2.addWeighted(nrjBtn, 1f)
        row2.addWeighted(funBtn, 1f)
        root.addWeighted(row2, 1f)

        setupScreen(root)

        if (PREWARM_ON_START) RadioService.warm(this)

        // Réglages manquants → écran de configuration au démarrage
        if (savedInstanceState == null && (!SetupActivity.allOk(this) || !themeChosen()) &&
            !getSharedPreferences("setup", MODE_PRIVATE).getBoolean("noAsk", false)
        ) {
            startActivity(Intent(this, SetupActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        if (ui().id != appliedTheme) { recreate(); return }   // thème changé dans ⚙
        RadioService.onChange = { refreshRadios() }
        Waze.onChange = { refreshWaze() }
        refreshLastCall()
        refreshWaze()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        RadioService.onChange = null
        Waze.onChange = null
        handler.removeCallbacks(ticker)
    }

    // ---------- Musique ----------

    private fun openMusic(autoClose: Boolean) {
        startActivity(Intent(this, MusicActivity::class.java).putExtra("autoClose", autoClose))
    }

    private fun refreshMusic() {
        if (!hasListenerAccess()) {
            mTitle.text = "♫ MUSIQUE"
            mArtist.text = "Toucher ici pour afficher le titre"
            mTime.text = ""
            mPlay.text = "⏯"
            return
        }
        val c = Music.controller(this)
        val title = c?.metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE)
        if (c == null || title == null) {
            val last = Music.last(this)
            mTitle.text = last?.first ?: "♫ ReFreezer"
            mArtist.text = last?.second ?: ""
            mTime.text = if (last != null) "Dernier écouté · ▶ pour relancer" else "▶ pour démarrer"
            mPlay.text = "▶"
            return
        }
        Music.remember(this, c)
        val (pos, dur) = Music.position(c, SystemClock.elapsedRealtime())
        mTitle.text = title
        mArtist.text = c.metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        mTime.text = if (dur > 0) "${Music.fmt(pos)} / ${Music.fmt(dur)}" else Music.fmt(pos)
        mPlay.text = if (Music.isPlaying(c)) "⏸" else "▶"
    }

    private fun mPrev() {
        Music.controller(this)?.transportControls?.skipToPrevious()
            ?: Music.mediaKey(this, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    }

    private fun mNext() {
        Music.controller(this)?.transportControls?.skipToNext()
            ?: Music.mediaKey(this, KeyEvent.KEYCODE_MEDIA_NEXT)
    }

    private fun mPlayPause() {
        if (!hasListenerAccess()) { Music.mediaKey(this, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE); return }
        val c = Music.controller(this)
        when {
            c == null -> openMusic(autoClose = true)   // démarre ReFreezer puis revient ici
            Music.isPlaying(c) -> c.transportControls.pause()
            else -> c.transportControls.play()
        }
    }

    // ---------- Dernier appel ----------

    private fun refreshLastCall() {
        if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            lastCallBtn.text = twoLine("📞 Dernier appel", "toucher pour autoriser", 0.7f)
            lastCall = null
            return
        }
        lastCall = try {
            contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE),
                null, null, "${CallLog.Calls.DATE} DESC"
            )?.use { c ->
                if (c.moveToFirst()) {
                    val num = c.getString(0) ?: ""
                    val name = c.getString(1)?.takeIf { it.isNotBlank() } ?: num
                    LastCall(name, num, c.getInt(2))
                } else null
            }
        } catch (e: Exception) {
            null
        }
        val lc = lastCall
        lastCallBtn.text = if (lc == null) "📞 Aucun appel" else {
            val type = when (lc.type) {
                CallLog.Calls.MISSED_TYPE -> "✖ manqué"
                CallLog.Calls.OUTGOING_TYPE -> "↗ appelé"
                else -> "↙ reçu"
            }
            twoLine("📞 ${lc.name}", type, 0.7f)
        }
    }

    private fun onLastCall() {
        if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_CALL_LOG, Manifest.permission.CALL_PHONE), 5)
            return
        }
        val num = lastCall?.num?.takeIf { it.isNotBlank() } ?: return
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num))))
        } else {
            pendingNumber = num
            requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), 6)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            5 -> refreshLastCall()
            6 -> {
                val num = pendingNumber ?: return
                pendingNumber = null
                val ok = grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
                startActivity(Intent(if (ok) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num))))
            }
        }
    }

    // ---------- Waze ----------

    private fun refreshWaze() {
        val lines = listOfNotNull(Waze.title, Waze.text)
        if (lines.isEmpty()) {
            wazeBtn.textSize = 56f
            wazeBtn.text = twoLine("➤", "WAZE")
        } else {
            wazeBtn.textSize = 30f
            wazeBtn.text = twoLine("➤ WAZE", lines.joinToString("\n"), 0.62f)
        }
    }

    // ---------- Radios ----------

    private fun toggle(r: Radio) {
        if (RadioService.isOn(r)) RadioService.stop(this) else RadioService.play(this, r)
        refreshRadios()
    }

    private fun refreshRadios() {
        label(nrjBtn, Radios.NRJ)
        label(funBtn, Radios.FUN)
    }

    private fun label(b: TextView, r: Radio) {
        val on = RadioService.isOn(r)
        val st = RadioService.stateOf(r)
        val left = RadioService.secondsToLive(r)
        val d = ".".repeat(dots)
        val err = RadioService.lastError?.takeIf { it.first == r }?.second
        val sub = when {
            on && st == RadioState.PLAYING && left > 0 -> "🔇 Pub sautée… ${left}s\n■ STOP"
            on && st == RadioState.PLAYING -> "🔊 En direct\n■ STOP"
            on && st == RadioState.RECONNECTING -> "⏳ Reconnexion$d"
            on -> "⏳ Recherche$d"
            err != null -> "⚠ $err\nToucher = réessayer"
            st == RadioState.PLAYING && left > 0 -> "▶ Écouter\n🔇 pub en cours… ${left}s"
            st == RadioState.PLAYING -> "▶ Écouter\n✓ prête, sans pub"
            st != null -> "▶ Écouter\n⏳ préparation$d"
            else -> "▶ Écouter"
        }
        b.text = twoLine(r.name, sub)
        b.alpha = if (RadioService.current != null && !on) 0.6f else 1f
    }
}
