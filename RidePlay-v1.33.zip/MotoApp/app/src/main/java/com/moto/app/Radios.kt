package com.moto.app

import android.content.Context

/**
 * search / alias : servent à retrouver tout seul la bonne adresse dans l'annuaire Radio Browser
 * si les adresses connues ne marchent plus.
 */
data class Radio(
    val id: String, val name: String, val urls: List<String>,
    val search: String = name, val alias: List<String> = emptyList()
)

/** Catalogue des radios proposées (adresses des flux en direct). */
object Radios {
    private fun nrjGroup(id: String, name: String, code: Int) = Radio(
        id, name, listOf(
            "https://cdn.nrjaudio.fm/audio1/fr/$code/mp3_128.mp3?origine=fluxradios",
            "http://cdn.nrjaudio.fm/audio1/fr/$code/mp3_128.mp3?origine=fluxradios"
        )
    )
    /** Nouvelles adresses du groupe NRJ (serveur streaming.nrjaudio.fm), avant les anciennes. */
    private fun nrjNew(r: Radio, token: String) = r.copy(urls = listOf(
        "https://streaming.nrjaudio.fm/$token?origine=fluxradios",
        "http://streaming.nrjaudio.fm/$token?origine=fluxradios"
    ) + r.urls)

    private fun radioFrance(id: String, name: String, slug: String) = Radio(
        id, name, listOf("https://icecast.radiofrance.fr/$slug-midfi.mp3", "http://icecast.radiofrance.fr/$slug-midfi.mp3")
    )

    val NRJ = nrjGroup("nrj", "NRJ", 30001)
    val FUN = Radio("fun", "FUN RADIO", listOf(
        "https://icecast.funradio.fr/fun-1-44-128", "http://icecast.funradio.fr/fun-1-44-128",
        "http://streamer-02.rtl.fr/fun-1-44-128"))
    val RTL2 = Radio("rtl2", "RTL2", listOf("https://icecast.rtl2.fr/rtl2-1-44-128", "http://icecast.rtl2.fr/rtl2-1-44-128"))
    val RTL = Radio("rtl", "RTL", listOf("https://icecast.rtl.fr/rtl-1-44-128", "http://icecast.rtl.fr/rtl-1-44-128"))
    val SKYROCK = Radio("skyrock", "SKYROCK", listOf("http://icecast.skyrock.net/s/natio_mp3_128k"))
    val CHERIE = nrjNew(nrjGroup("cherie", "CHÉRIE FM", 30201), "ouuku85n3nje").copy(search = "Cherie", alias = listOf("Chérie FM", "Cherie FM"))
    // Rire & Chansons : la radio principale en direct (pas une webradio thématique)
    val RIRE = nrjNew(nrjGroup("rire", "RIRE & CHANSONS", 30401), "ou8o8xgk7oiu").copy(search = "Rire", alias = listOf("Rire et Chansons", "Rire & Chansons"))
    val NOSTALGIE = nrjNew(nrjGroup("nostalgie", "NOSTALGIE", 30601), "oug7girb92oc")
    val INTER = radioFrance("inter", "FRANCE INTER", "franceinter")
    val INFO = radioFrance("info", "FRANCEINFO", "franceinfo")
    val FIP = radioFrance("fip", "FIP", "fip")
    val MOUV = radioFrance("mouv", "MOUV'", "mouv").copy(search = "Mouv")

    val catalog = listOf(NRJ, FUN, RTL2, SKYROCK, NOSTALGIE, CHERIE, RIRE, RTL, INTER, INFO, FIP, MOUV)

    /** Radio perso : « custom:Nom|adresse ». */
    fun custom(name: String, url: String) = Radio("custom:${name.replace("|", " ")}|$url", name.uppercase(), listOf(url))

    fun byId(id: String?): Radio? {
        if (id == null) return null
        if (id.startsWith("custom:")) {
            val rest = id.removePrefix("custom:")
            val name = rest.substringBefore("|")
            val url = rest.substringAfter("|", "")
            return if (url.isBlank()) null else Radio(id, name.uppercase(), listOf(url))
        }
        return catalog.find { it.id == id }
    }
}

/** Les radios affichées sur l'accueil : 2 ou 4 cases, chacune choisie dans le catalogue. */
object RadioSlots {
    private val defaults = listOf(Radios.NRJ, Radios.FUN, Radios.RTL2, Radios.SKYROCK)
    private fun p(ctx: Context) = ctx.getSharedPreferences("radios", Context.MODE_PRIVATE)

    fun count(ctx: Context) = p(ctx).getInt("count", 2).coerceIn(1, 4)
    fun setCount(ctx: Context, n: Int) = p(ctx).edit().putInt("count", n.coerceIn(1, 4)).apply()

    fun slot(ctx: Context, i: Int): Radio = Radios.byId(p(ctx).getString("slot$i", null)) ?: defaults[i]
    fun setSlot(ctx: Context, i: Int, r: Radio) = p(ctx).edit().putString("slot$i", r.id).apply()

    fun home(ctx: Context) = (0 until count(ctx)).map { slot(ctx, it) }

    /** Pour recréer l'accueil si les radios ont changé. */
    fun signature(ctx: Context) = home(ctx).joinToString(",") { it.id }

    /** Les 2 radios écoutées le plus récemment (gardées prêtes sans pub). */
    fun markUsed(ctx: Context, r: Radio) {
        val rec = (listOf(r.id) + p(ctx).getString("recent", "")!!.split("\n").filter { it.isNotBlank() && it != r.id }).take(2)
        p(ctx).edit().putString("recent", rec.joinToString("\n")).apply()
    }

    /** Toutes les radios affichées sur l'accueil sont préparées en silence (sans pub). */
    fun warmList(ctx: Context): List<Radio> = home(ctx)
}
