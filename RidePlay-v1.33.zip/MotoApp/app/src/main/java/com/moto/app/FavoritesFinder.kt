package com.moto.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.browse.MediaBrowser
import android.os.Handler
import android.os.Looper

/**
 * Parcourt le catalogue que ReFreezer expose (celui d'Android Auto)
 * pour trouver « Favoris / Titres aimés » et renvoie l'identifiant à lancer.
 */
/** Ce qu'on cherche dans le catalogue de ReFreezer. */
enum class MusicTarget { FAVORITES, FLOW }

class FavoritesFinder(
    private val ctx: Context,
    private val pkg: String,
    private val target: MusicTarget = MusicTarget.FAVORITES,
    private val done: (String?) -> Unit
) {
    private var browser: MediaBrowser? = null
    private val handler = Handler(Looper.getMainLooper())
    private val queue = ArrayDeque<Pair<String, Int>>()
    private var best: MediaBrowser.MediaItem? = null
    private var bestScore = 0
    private var visited = 0
    private var finished = false

    private fun score(title: String): Int {
        val t = title.lowercase()
        if (target == MusicTarget.FLOW) return when {
            Regex("\\bflow\\b").containsMatchIn(t) -> 2          // « Flow », « Mon Flow »
            listOf("mix", "pour vous", "for you").any { it in t } -> 1
            else -> 0
        }
        return when {
            listOf("favori", "coup de c", "coups de c", "loved", "favorite", "liked", "aimé").any { it in t } -> 2
            listOf("titres", "tracks").any { it in t } -> 1
            else -> 0
        }
    }

    fun start() {
        val si = ctx.packageManager.queryIntentServices(
            Intent("android.media.browse.MediaBrowserService").setPackage(pkg), 0
        ).firstOrNull()
        if (si == null) { finish(null); return }

        handler.postDelayed({ finish(best?.takeIf { it.isPlayable }?.mediaId) }, 8000)

        browser = MediaBrowser(ctx, ComponentName(pkg, si.serviceInfo.name),
            object : MediaBrowser.ConnectionCallback() {
                override fun onConnected() {
                    browser?.let { queue.add(it.root to 0) }
                    next()
                }
                override fun onConnectionFailed() = finish(null)
                override fun onConnectionSuspended() = finish(null)
            }, null
        ).also { it.connect() }
    }

    private fun next() {
        if (finished) return
        if (bestScore >= 2 || queue.isEmpty() || visited >= 15) { pick(); return }
        val (id, depth) = queue.removeFirst()
        visited++
        val b = browser ?: return finish(null)
        b.subscribe(id, object : MediaBrowser.SubscriptionCallback() {
            override fun onChildrenLoaded(parentId: String, children: MutableList<MediaBrowser.MediaItem>) {
                b.unsubscribe(parentId)
                for (item in children) {
                    val s = score(item.description.title?.toString() ?: "")
                    if (s > bestScore) { bestScore = s; best = item }
                    val mid = item.mediaId
                    if (item.isBrowsable && depth < 2 && mid != null) queue.add(mid to depth + 1)
                }
                next()
            }
            override fun onError(parentId: String) = next()
        })
    }

    private fun pick() {
        val item = best ?: return finish(null)
        val mid = item.mediaId ?: return finish(null)
        if (item.isPlayable) return finish(mid)
        // C'est un dossier : on lance son premier titre
        val b = browser ?: return finish(null)
        b.subscribe(mid, object : MediaBrowser.SubscriptionCallback() {
            override fun onChildrenLoaded(parentId: String, children: MutableList<MediaBrowser.MediaItem>) =
                finish(children.firstOrNull { it.isPlayable }?.mediaId)
            override fun onError(parentId: String) = finish(null)
        })
    }

    private fun finish(id: String?) {
        if (finished) return
        finished = true
        handler.removeCallbacksAndMessages(null)
        try { browser?.disconnect() } catch (_: Exception) {}
        done(id)
    }
}
