package com.moto.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.CallLog
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private data class LastCall(val name: String, val num: String, val type: Int)

    private lateinit var mTitle: TextView
    private lateinit var mArtist: TextView
    private lateinit var mTime: TextView
    private lateinit var mPlay: TextView
    private lateinit var lastCallBtn: TextView
    private lateinit var wazeBtn: TextView
    /** Cases radio de l'accueil (2 ou 4), chacune avec sa radio. */
    private val radioBtns = mutableListOf<Pair<TextView, Radio>>()
    private var appliedRadios = ""

    private val handler = Handler(Looper.getMainLooper())
    private var dots = 0
    private var lastCall: LastCall? = null
    private var pendingNumber: String? = null
    private var appliedTheme = ""
    private var eqView: EqualizerView? = null
    private var shuffleBtn: IconTextView? = null
    private var flowBtn: IconTextView? = null
    private var waitingPlay = 0L      // démarrage de ReFreezer en arrière-plan
    private var kicked = false

    private val ticker = object : Runnable {
        override fun run() {
            dots = (dots + 1) % 4
            refreshMusic()
            refreshRadios()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val t = ui()
        appliedTheme = t.id
        appliedRadios = RadioSlots.signature(this)
        val root = vbox()

        if (isInMultiWindowMode) {
            buildCompact(root, t)
        } else {
            // ---------- Barre du haut : nom + ⚙ ----------
            val top = hbox().apply { gravity = Gravity.CENTER_VERTICAL }
            top.addView(label(18f, t.onBg, bold = true).apply {
                text = "RIDEPLAY"
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                letterSpacing = 0.18f
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply { marginStart = dp(12) })
            val gear = iconButton(Ic.GEAR, null, t.neutral, 26) {
                startActivity(Intent(this, SetupActivity::class.java))
            }.apply { contentDescription = "Paramètres"; setPadding(0, 0, 0, 0) }
            top.addView(gear, LinearLayout.LayoutParams(dp(68), LinearLayout.LayoutParams.MATCH_PARENT).apply {
                setMargins(dp(5), dp(3), dp(5), dp(3))
            })
            root.addView(top, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(56)))

            // ---------- Musique : lecture en cours + commandes ----------
            val card = vbox().apply { background = shape(t.music, t) }
            val info = vbox().apply {
                gravity = Gravity.CENTER
                isClickable = true
                setOnClickListener {
                    it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    if (!hasListenerAccess()) startActivity(Intent(this@MainActivity, SetupActivity::class.java))
                    else openMusic(autoClose = false)
                }
                // appui long sur le titre = réglages
                setOnLongClickListener {
                    startActivity(Intent(this@MainActivity, SetupActivity::class.java)); true
                }
            }
            mTitle = label(24f, t.music.text, bold = true)
            mArtist = label(18f, withAlpha(t.music.text, 0xC0))
            mTime = label(16f, t.music.text)
            info.addFullWidth(mTitle)
            info.addFullWidth(mArtist)
            if (t.eq) {
                eqView = EqualizerView(this, t.accent).also {
                    info.addView(it, LinearLayout.LayoutParams(dp(96), dp(22)).apply {
                        gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(4); bottomMargin = dp(2)
                    })
                }
            }
            info.addFullWidth(mTime)

            // petit bouton « aléatoire » discret, en haut à droite de la carte musique
            val infoBox = android.widget.FrameLayout(this)
            infoBox.addView(info, android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT, android.widget.FrameLayout.LayoutParams.MATCH_PARENT))
            val sb = iconButton(Ic.HEART, null, t.music, 30) { favShortcut() } as IconTextView
            sb.contentDescription = "Favoris en aléatoire"
            shuffleBtn = sb
            infoBox.addView(sb, android.widget.FrameLayout.LayoutParams(dp(66), dp(54), Gravity.TOP or Gravity.END).apply {
                setMargins(0, dp(4), dp(4), 0)
            })
            // à gauche : « Mon Flow »
            val fb = iconButton(Ic.FLOW, null, t.music, 30) { flowShortcut() } as IconTextView
            fb.contentDescription = "Mon Flow"
            flowBtn = fb
            infoBox.addView(fb, android.widget.FrameLayout.LayoutParams(dp(66), dp(54), Gravity.TOP or Gravity.START).apply {
                setMargins(dp(4), dp(4), 0, 0)
            })
            card.addWeighted(infoBox, 1f)
            updateShuffle()

            val ctr = hbox()
            ctr.addWeighted(iconButton(Ic.PREV, null, t.ctrl, 42) { mPrev() }, 1f)
            mPlay = iconButton(Ic.PLAY, null, t.play, 46) { mPlayPause() }
            ctr.addWeighted(mPlay, 1f)
            ctr.addWeighted(iconButton(Ic.NEXT, null, t.ctrl, 42) { mNext() }, 1f)
            card.addWeighted(ctr, 0.9f)
            root.addWeighted(card, 1.35f)

            // ---------- Contacts (+ dernier appel) / Waze ----------
            val row1 = hbox()
            val cBox = vbox()
            cBox.addWeighted(tile(Ic.PHONE, "CONTACTS", t.contacts, 30, 22f) {
                startActivity(Intent(this, ContactsActivity::class.java))
            }, 1.5f)
            lastCallBtn = tile(Ic.CALL, "", t.contactsSub, 22, 17f, left = true) { onLastCall() }
            lastCallBtn.maxLines = 2
            cBox.addWeighted(lastCallBtn, 1f)
            row1.addWeighted(cBox, 1f)

            wazeBtn = tile(Ic.NAV, "", t.waze, 30, 22f) { splitWithWaze() }
            wazeBtn.setOnLongClickListener { launchApp(WAZE_PKG, "Waze"); true }   // appui long = plein écran
            wazeBtn.maxLines = 7
            row1.addWeighted(wazeBtn, 1f)
            root.addWeighted(row1, 1.15f)

            // ---------- Radios ----------
            val radios = RadioSlots.home(this)
            val styles = listOf(t.nrj, t.funR, t.funR, t.nrj)          // en damier
            val four = radios.size > 2
            val radioBox = vbox()
            radios.chunked(2).forEachIndexed { rowIdx, pair ->
                val row = hbox()
                pair.forEachIndexed { k, radio ->
                    val i = rowIdx * 2 + k
                    val b = tile(Ic.RADIO, "", styles[i], if (four) 22 else 30, if (four) 18f else 22f,
                        left = four) { toggle(radio) }
                    radioBtns += b to radio
                    row.addWeighted(b, 1f)
                }
                radioBox.addWeighted(row, 1f)
            }
            root.addWeighted(radioBox, when (radios.size) { 1 -> 0.9f; 2 -> 1.15f; else -> 1.5f })

        }
        setupScreen(root)

        if (PREWARM_ON_START) RadioService.warm(this)

        // Réglages manquants → écran de configuration au démarrage
        if (savedInstanceState == null && (!SetupActivity.allOk(this) || !themeChosen()) &&
            !getSharedPreferences("setup", MODE_PRIVATE).getBoolean("noAsk", false)
        ) {
            startActivity(Intent(this, SetupActivity::class.java))
        }
    }

    // ---------- Mode compact (écran partagé avec Waze) ----------

    /** Bandeau de gros boutons quand Moto partage l'écran avec Waze. */
    private fun buildCompact(root: LinearLayout, t: Theme) {
        // Ligne 1 : titre en cours + ⏮ ▶ ⏭
        val row1 = hbox()
        val info = vbox().apply {
            gravity = Gravity.CENTER
            background = shape(t.music, t)
            setPadding(dp(6), dp(4), dp(6), dp(4))
            isClickable = true
            setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                openMusic(autoClose = false)
            }
        }
        mTitle = label(17f, t.music.text, bold = true).apply { maxLines = 1 }
        mArtist = label(14f, withAlpha(t.music.text, 0xC0)).apply { maxLines = 1 }
        mTime = label(13f, t.music.text).apply { maxLines = 1 }
        info.addFullWidth(mTitle)
        info.addFullWidth(mArtist)
        info.addFullWidth(mTime)
        row1.addWeighted(info, 1.5f)
        row1.addWeighted(iconButton(Ic.PREV, null, t.ctrl, 32) { mPrev() }, 0.75f)
        mPlay = iconButton(Ic.PLAY, null, t.play, 36) { mPlayPause() }
        row1.addWeighted(mPlay, 0.75f)
        row1.addWeighted(iconButton(Ic.NEXT, null, t.ctrl, 32) { mNext() }, 0.75f)
        root.addWeighted(row1, 1f)

        // Ligne 2 : dernier appel, NRJ, FUN, ⚙
        val row2 = hbox()
        lastCallBtn = tile(Ic.CALL, "", t.contactsSub, 18, 14f, left = true) { onLastCall() }
        lastCallBtn.maxLines = 2
        lastCallBtn.setOnLongClickListener { startActivity(Intent(this, ContactsActivity::class.java)); true }
        row2.addWeighted(lastCallBtn, 1.2f)
        // en écran partagé : les 2 premières radios de l'accueil
        RadioSlots.home(this).take(2).forEachIndexed { i, radio ->
            val b = tile(Ic.RADIO, "", if (i == 0) t.nrj else t.funR, 20, 16f, left = true) { toggle(radio) }
            radioBtns += b to radio
            row2.addWeighted(b, 1f)
        }
        row2.addWeighted(iconButton(Ic.GEAR, null, t.neutral, 24) {
            startActivity(Intent(this, SetupActivity::class.java))
        }.apply { contentDescription = "Paramètres" }, 0.45f)
        root.addWeighted(row2, 1f)

        // Waze est déjà visible à côté : case gardée hors écran pour le code commun
        wazeBtn = tile(Ic.NAV, "", t.waze, 20, 16f) { launchApp(WAZE_PKG, "Waze") }
    }

    /** Ouvre Waze dans l'autre moitié de l'écran (si le téléphone l'accepte). */
    private fun splitWithWaze() {
        val pkg = findPackage(WAZE_PKG, "Waze")
        val intent = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
        if (intent == null) { toast("Waze introuvable sur le téléphone"); return }
        intent.addFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        if (!isInMultiWindowMode) {
            // Beaucoup de téléphones refusent de partager l'écran tout seuls : on explique (3 fois max)
            val p = getSharedPreferences("ui", MODE_PRIVATE)
            val shown = p.getInt("splitHint", 0)
            if (shown < 3) {
                p.edit().putInt("splitHint", shown + 1).apply()
                handler.postDelayed({
                    if (!isInMultiWindowMode) toast(
                        "Écran partagé : applis récentes → appui long sur Waze → « Écran partagé » → choisis RidePlay"
                    )
                }, 1500)
            }
        }
    }

    override fun onMultiWindowModeChanged(isInMultiWindowMode: Boolean, newConfig: android.content.res.Configuration) {
        super.onMultiWindowModeChanged(isInMultiWindowMode, newConfig)
        recreate()   // bascule entre accueil normal et bandeau compact
    }

    override fun onResume() {
        super.onResume()
        if (ui().id != appliedTheme || RadioSlots.signature(this) != appliedRadios) { recreate(); return }   // changé dans ⚙
        RadioService.onChange = { refreshRadios() }
        Waze.onChange = { refreshWaze() }
        refreshLastCall()
        refreshWaze()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        RadioService.onChange = null
        Waze.onChange = null
        handler.removeCallbacks(ticker)
    }

    // ---------- Musique ----------

    private fun openMusic(autoClose: Boolean) {
        startActivity(Intent(this, MusicActivity::class.java).putExtra("autoClose", autoClose))
    }

    private fun refreshMusic() {
        eqView?.playing = Music.isPlaying(Music.controller(this))
        updateShuffle()
        if (!hasListenerAccess()) {
            mTitle.text = "♫ MUSIQUE"
            mArtist.text = "Toucher ici pour afficher le titre"
            mTime.text = ""
            mPlay.setIcon(Ic.PLAY)
            return
        }
        val c = Music.controller(this)
        if (waitingPlay > 0) checkBackgroundStart(c)
        if (Music.loading != null) {
            mTitle.text = Music.loadingText(Music.loading)
            mArtist.text = ""
            mTime.text = ""
            mPlay.setIcon(Ic.PAUSE)
            return
        }
        val title = c?.metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE)
        if (c == null || title == null) {
            val last = Music.last(this)
            mTitle.text = last?.first ?: "♫ ReFreezer"
            mArtist.text = last?.second ?: ""
            mTime.text = when {
                waitingPlay > 0 -> "Démarrage de la musique…"
                last != null -> "Dernier écouté · lecture pour relancer"
                else -> "lecture pour démarrer"
            }
            mPlay.setIcon(Ic.PLAY)
            return
        }
        Music.remember(this, c)
        val (pos, dur) = Music.position(c, SystemClock.elapsedRealtime())
        mTitle.text = title
        mArtist.text = c.metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        mTime.text = if (dur > 0) "${Music.fmt(pos)} / ${Music.fmt(dur)}" else Music.fmt(pos)
        mPlay.setIcon(if (Music.isPlaying(c)) Ic.PAUSE else Ic.PLAY)
    }

    // ---------- Raccourci : favoris en aléatoire ----------

    private fun favShortcut() {
        if (!hasListenerAccess()) { startActivity(Intent(this, SetupActivity::class.java)); return }
        if (Music.controller(this) == null) {
            // ReFreezer fermé : on l'ouvre, on lance les favoris, puis retour ici
            startActivity(Intent(this, MusicActivity::class.java).putExtra("autoClose", true).putExtra("fav", true))
            return
        }
        mTitle.text = Music.loadingText(MusicTarget.FAVORITES); mArtist.text = ""; mTime.text = ""
        Music.setMode(this, MusicTarget.FAVORITES); updateShuffle()      // retour visuel immédiat
        Music.playFavorites(this) { toast(it) }
    }

    private fun flowShortcut() {
        if (!hasListenerAccess()) { startActivity(Intent(this, SetupActivity::class.java)); return }
        if (Music.controller(this) == null) {
            startActivity(Intent(this, MusicActivity::class.java).putExtra("autoClose", true).putExtra("flow", true))
            return
        }
        mTitle.text = Music.loadingText(MusicTarget.FLOW); mArtist.text = ""; mTime.text = ""
        Music.setMode(this, MusicTarget.FLOW); updateShuffle()
        Music.playFlow(this) { toast(it) }
    }

    private val shortcutState = HashMap<IconTextView, String>()

    /**
     * Flow (gauche) / Favoris (droite) :
     * repos = contour fin ; en cours et ça joue = pastille pleine couleur accent ; en pause = contour accent.
     */
    private fun updateShuffle(c: android.media.session.MediaController? = Music.controller(this)) {
        val t = ui()
        val active = Music.activeTarget(this, c)
        val playing = Music.isPlaying(c)
        for ((b, target) in listOfNotNull(flowBtn?.let { it to MusicTarget.FLOW }, shuffleBtn?.let { it to MusicTarget.FAVORITES })) {
            val state = when {
                active == target && playing -> "on"
                active == target && c != null -> "pause"      // en pause, ou en cours de lancement
                else -> "off"
            }
            if (shortcutState[b] == state) continue
            shortcutState[b] = state
            val st = when (state) {
                "on" -> Style(t.play.fill, t.play.text)
                "pause" -> Style(android.graphics.Color.TRANSPARENT, t.play.fill.let { if (it == t.music.fill) t.music.text else it },
                    t.play.fill.let { if (it == t.music.fill) t.music.text else it }, 2)
                else -> Style(android.graphics.Color.TRANSPARENT, withAlpha(t.music.text, 0xC0), withAlpha(t.music.text, 0x55), 1)
            }
            b.background = android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(0x55888888), shapeFlat(st, t), null)
            b.icon?.setColor(st.text)
            b.refresh()
            b.contentDescription = (if (target == MusicTarget.FLOW) "Mon Flow" else "Favoris en aléatoire") +
                (if (state == "on") ", en cours" else "")
        }
    }

    private fun mPrev() {
        Music.controller(this)?.transportControls?.skipToPrevious()
            ?: run { if (!Music.safeKey(this, KeyEvent.KEYCODE_MEDIA_PREVIOUS)) toast("Lance d'abord la musique avec ▶") }
    }

    private fun mNext() {
        Music.controller(this)?.transportControls?.skipToNext()
            ?: run { if (!Music.safeKey(this, KeyEvent.KEYCODE_MEDIA_NEXT)) toast("Lance d'abord la musique avec ▶") }
    }

    private fun mPlayPause() {
        if (!hasListenerAccess()) {
            if (!Music.safeKey(this, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)) openMusic(autoClose = true)
            return
        }
        val c = Music.controller(this)
        when {
            c == null -> openMusic(autoClose = true)    // ouvre ReFreezer, lance, revient ici
            Music.isPlaying(c) -> c.transportControls.pause()
            else -> c.transportControls.play()
        }
    }

    /**
     * ReFreezer fermé : on envoie « lecture » comme un bouton de casque.
     * Android relance ReFreezer en arrière-plan, sans l'afficher.
     * Seulement si rien ne démarre après 6 s, on l'ouvre (puis retour auto).
     */
    private fun startInBackground() {
        openMusic(autoClose = true)
    }

    private fun checkBackgroundStart(c: android.media.session.MediaController?) {
        val el = SystemClock.elapsedRealtime() - waitingPlay
        when {
            Music.isPlaying(c) -> waitingPlay = 0
            c != null && el > 1500 && !kicked -> { kicked = true; c.transportControls.play() }
            el > 6000 -> { waitingPlay = 0; openMusic(autoClose = true) }
        }
    }

    // ---------- Dernier appel ----------

    private fun refreshLastCall() {
        if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            lastCallBtn.text = twoLine("Dernier appel", "toucher pour autoriser", 0.7f)
            lastCall = null
            return
        }
        lastCall = try {
            contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE),
                null, null, "${CallLog.Calls.DATE} DESC"
            )?.use { c ->
                if (c.moveToFirst()) {
                    val num = c.getString(0) ?: ""
                    val name = c.getString(1)?.takeIf { it.isNotBlank() } ?: num
                    LastCall(name, num, c.getInt(2))
                } else null
            }
        } catch (e: Exception) {
            null
        }
        val lc = lastCall
        lastCallBtn.text = if (lc == null) "Aucun appel" else {
            val type = when (lc.type) {
                CallLog.Calls.MISSED_TYPE -> "manqué · rappeler"
                CallLog.Calls.OUTGOING_TYPE -> "appelé · rappeler"
                else -> "reçu · rappeler"
            }
            twoLine(lc.name, type, 0.7f)
        }
    }

    private fun onLastCall() {
        if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_CALL_LOG, Manifest.permission.CALL_PHONE), 5)
            return
        }
        val num = lastCall?.num?.takeIf { it.isNotBlank() } ?: return
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num))))
        } else {
            pendingNumber = num
            requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), 6)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            5 -> refreshLastCall()
            6 -> {
                val num = pendingNumber ?: return
                pendingNumber = null
                val ok = grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
                startActivity(Intent(if (ok) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num))))
            }
        }
    }

    // ---------- Waze ----------

    private fun refreshWaze() {
        val lines = listOfNotNull(Waze.title, Waze.text)
        if (lines.isEmpty()) {
            if (isInMultiWindowMode) return
            wazeBtn.text = twoLine("WAZE", "écran partagé", 0.6f)
        } else {
            wazeBtn.text = twoLine("WAZE", lines.joinToString("\n"), 0.6f)
        }
    }

    // ---------- Radios ----------

    private fun toggle(r: Radio) {
        if (RadioService.isOn(r)) RadioService.stop(this) else RadioService.play(this, r)
        refreshRadios()
    }

    private fun refreshRadios() {
        radioBtns.forEach { (b, r) -> label(b, r) }
    }

    private fun label(b: TextView, r: Radio) {
        val on = RadioService.isOn(r)
        val st = RadioService.stateOf(r)
        val left = RadioService.secondsToLive(r)
        val d = ".".repeat(dots)
        val err = RadioService.lastError?.takeIf { it.first == r }?.second
        val sub = when {
            on && st == RadioState.PLAYING && left > 0 -> "pub sautée… ${left}s · stop"
            on && st == RadioState.PLAYING -> "en direct · stop"
            on && st == RadioState.RECONNECTING -> "reconnexion$d"
            on -> "recherche$d"
            err != null -> "erreur · réessayer\n$err"
            st == RadioState.PLAYING && left > 0 -> "pub en cours… ${left}s"
            st == RadioState.PLAYING -> "prête, sans pub"
            st != null -> "préparation$d"
            else -> "écouter"
        }
        b.text = twoLine(r.name, sub)
        b.alpha = if (RadioService.current != null && !on) 0.6f else 1f
    }
}
