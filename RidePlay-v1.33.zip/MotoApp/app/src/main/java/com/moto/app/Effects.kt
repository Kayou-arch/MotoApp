package com.moto.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.view.View
import java.util.Random
import kotlin.math.abs

/**
 * Case « néon » : fond + contour, entourés d'un halo lumineux dégradé.
 * Le halo est dessiné en anneaux de plus en plus transparents (marche sur tous les téléphones).
 */
class GlowDrawable(
    private val fill: Int, private val stroke: Int, private val strokeW: Float,
    private val radius: Float, private val glow: Float, private val glowColor: Int
) : Drawable() {
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fill; style = Paint.Style.FILL }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = stroke; style = Paint.Style.STROKE; strokeWidth = strokeW }
    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val steps = 7

    private fun base() = RectF(bounds).apply { inset(glow, glow) }

    override fun draw(c: Canvas) {
        val r = base()
        val stepW = glow / steps
        haloPaint.strokeWidth = stepW + 1f
        for (k in steps downTo 1) {
            val f = 1f - k / (steps + 1f)
            haloPaint.color = withAlpha(glowColor, (110 * f * f).toInt())
            val o = RectF(r).apply { inset(-k * stepW + stepW / 2, -k * stepW + stepW / 2) }
            c.drawRoundRect(o, radius + k * stepW, radius + k * stepW, haloPaint)
        }
        c.drawRoundRect(r, radius, radius, fillPaint)
        if (strokeW > 0f) {
            val s = RectF(r).apply { inset(strokeW / 2, strokeW / 2) }
            c.drawRoundRect(s, radius, radius, strokePaint)
        }
    }

    override fun getOutline(outline: Outline) {
        val r = base()
        outline.setRoundRect(r.left.toInt(), r.top.toInt(), r.right.toInt(), r.bottom.toInt(), radius)
    }
    override fun setAlpha(alpha: Int) { fillPaint.alpha = alpha; strokePaint.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { fillPaint.colorFilter = cf; strokePaint.colorFilter = cf }
    @Deprecated("API Drawable")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}

/** Petit égaliseur qui danse seulement quand la musique joue (s'arrête sinon : batterie). */
class EqualizerView(ctx: Context, color: Int) : View(ctx) {
    private val bars = 7
    private val h = FloatArray(bars) { 0.15f }
    private val target = FloatArray(bars) { 0.15f }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
    private val rnd = Random()

    var playing = false
        set(v) {
            if (field == v) return
            field = v
            removeCallbacks(tick)
            post(tick)
        }

    private val tick = object : Runnable {
        override fun run() {
            var moving = false
            for (i in 0 until bars) {
                if (!playing) target[i] = 0.15f
                else if (abs(h[i] - target[i]) < 0.05f) target[i] = 0.2f + rnd.nextFloat() * 0.8f
                h[i] += (target[i] - h[i]) * 0.35f
                if (abs(h[i] - target[i]) > 0.01f) moving = true
            }
            invalidate()
            if ((playing || moving) && isAttachedToWindow) postDelayed(this, 55)
        }
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val hh = height.toFloat()
        val bw = w / (bars * 1.6f)
        val gap = bw * 0.6f
        var x = (w - (bars * bw + (bars - 1) * gap)) / 2
        for (i in 0 until bars) {
            val bh = hh * h[i]
            c.drawRoundRect(x, hh - bh, x + bw, hh, bw / 3, bw / 3, paint)
            x += bw + gap
        }
    }
}
